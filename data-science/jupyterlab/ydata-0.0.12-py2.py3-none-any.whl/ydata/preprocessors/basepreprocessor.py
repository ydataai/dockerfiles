from __future__ import absolute_import, division, print_function

from datetime import datetime

class Basepreprocessor(object):

    def __init__(self, metadata):
        self.metadata = metadata
        self._pipeline = None

    @property
    def pipeline(self):
        if self._pipeline is None:
            self._pipeline = {
                'outliers': [],
                'missing_values': [],
                'transformations': {var:[] for var in self.metadata.variables},
                'created': datetime.utcnow()
            }
        return self._pipeline

    def _fit_continuous(self):
        raise NotImplementedError

    def _fit_discrete(self):
        raise NotImplementedError

    def _transform_continuos(self):
        raise NotImplementedError

    def _transform_discrete(self):
        raise NotImplementedError

    def _missing_val(self):
        raise NotImplementedError

    def _outliers(self, return_outliers=False):
        raise NotImplementedError

    def fit_transform(self):
        raise NotImplementedError

    def inverse_transform(self):
        raise NotImplementedError