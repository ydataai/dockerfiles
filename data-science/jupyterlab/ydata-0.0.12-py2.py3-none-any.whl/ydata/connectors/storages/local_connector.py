from __future__ import absolute_import, division, print_function

import os
import pandas as pd

from ydata.connectors.exceptions import DataConnectorsException
from ydata.connectors.storages import _LOCAL_STORAGE, _CSV, _EXCEL, _PARQUET, _FILE_TYPES
from ydata.connectors.storages.base_connector import BaseConnector

class LocalConnector(BaseConnector):
    STORAGE_TYPE = _LOCAL_STORAGE
    
    def __init__(self):
        BaseConnector.__init__(self)
        
    @staticmethod
    def _list(path, check, abs_path=False):
        """
            List all entities directly under 'dir_name' that satisfy 'filter_func'
            Args:
                path: path where to start search
                check: function to check whether or not to include the results.
                abs_path: If True will return results with abs path.
            Returns:
                list of all files or directories under the path after the check.
        """
        if not os.path.isdir(path):
            raise Exception("Invalid parent directory '%s'" % path)
        matches = [x for x in os.listdir(path) if check(os.path.join(path, x))]
        return [os.path.join(path, m) for m in matches] if abs_path else matches

    @staticmethod
    def parse_local_path(path):
        split = os.path.splitext(path)
        path = split[0]
        extension = split[1]
        return path, extension

    def ls(self, path):
        return self.list(path=path)

    def list(self, path, abs_path=False):
        def list_dirs():
            return self._list(path, os.path.isdir, abs_path)

        def list_files():
            matches = self._list(path, os.path.isfile, abs_path)
            if abs_path:
                return [(f, os.path.getsize(f)) for f in matches]
            return [(f, os.path.getsize(os.path.join(path, f))) for f in matches]

        return {
            'dirs': list_dirs(),
            'files': list_files()
        }

    def read_file(self, path, file_type=_CSV):
        """
        Reads files given from a local file path
        :param path: the path for the local file
        :param file_type: the extension of the file. Default is .csv
        :return: a pandas dataframe with the file
        """
        assert file_type in _FILE_TYPES, f"Provided file type {file_type} is not supported."

        def read_file(path, file_type, **kwargs):
            with open(path, 'r') as f:
                data = pd.read(file_type, f, **kwargs)
            return data

        assert file_type in _FILE_TYPES, f"Provided file type {file_type} is not supported."

        if os.path.isdir(path):
            ls_data = []
            files = self._list(path, check=os.path.isfile, abs_path=True)
            files = [file for file in files if file_type in file]
        else:
            files = [path]

        ls_data=[]
        for file in files:
            try:
                if file_type == _EXCEL:
                    ls_data.apend(pd.read_excel(file))
                elif file_type == _PARQUET:
                    ls_data.append(pd.read_parquet(file))
                else:
                    ls_data.append(pd.read_csv(file))
            except FileNotFoundError:
                DataConnectorsException(f'{file} does not exist or access not allowed.')
        try:
            dataset = pd.concat(ls_data)
        except:
            raise DataConnectorsException('Files in the same directory do not have the same format. Please verify your datasource.')

        return dataset

    def write_to(self, dataset, path):
        file_type = self.parse_local_path(path)[1][1:]
        if file_type == _EXCEL:
            with open(path, 'w') as f:
                dataset.to_excel(f)
        elif file_type == _PARQUET:
            with open(path, 'wb') as f:
                dataset.to_parquet(f)
        else:
            with open(path, 'w') as f:
                dataset.to_csv(f)


if __name__ == '__main__':
    
    connector = LocalConnector()

    data = connector.read_file('/home/fabiana/PycharmProjects/YData/data-connectors/datasets/data.csv', file_type=_CSV)
    connector.write_to(data, '/home/fabiana/PycharmProjects/YData/data-connectors/datasets/teste_sample.csv')



            
            
