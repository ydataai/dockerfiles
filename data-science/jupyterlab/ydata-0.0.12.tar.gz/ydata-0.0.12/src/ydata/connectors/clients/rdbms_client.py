from sqlalchemy.engine import create_engine

from ydata.connectors.storages import _RDBMS_TYPES

def create_db_engine(username, password, server_name, port, database_type, database_name):
    # sqlalchemy.create_engine('mysql://user:password@server')
    url = f'{username}:{password}@{server_name}'

    if database_name is None:
        database_name=''

    if port is not None:
        url += f':{port}'
    #Aqui preciso de ir constuindo o URL dependendo do input - inclui o port por exemplo
    if database_type=='mysql':
        engine = create_engine(f'{database_type}+mysqlconnector://'+url+f'/{database_name}')
    return engine