from __future__ import absolute_import, division, print_function

from azure.storage.blob import BlobServiceClient
from azure.storage.filedatalake import DataLakeServiceClient

from ydata.connectors.utils import get_from_env

def get_account_name(keys=None):
    keys = keys or ['AZURE_ACCOUNT_NAME']
    return get_from_env(keys)

def get_account_key(keys=None):
    keys = keys or ['AZURE_ACCOUNT_KEY']
    return get_from_env(keys)

def get_connection_string(keys=None):
    keys = keys or ['AZURE_CONNECTION_STRING']
    return get_from_env(keys)

def get_blob_service_connection(connection_string=None):
    connection_string = connection_string or get_connection_string()
    return BlobServiceClient.from_connection_string(connection_string)

def get_datalake_service_connection(connection_string=None):
    connection_string = connection_string or get_connection_string()
    return DataLakeServiceClient.from_connection_string(connection_string)