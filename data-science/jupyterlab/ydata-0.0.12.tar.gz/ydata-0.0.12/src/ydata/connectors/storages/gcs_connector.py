from __future__ import absolute_import, division, print_function

import os
import json
from rhea import rhea_parser
from rhea.exceptions import RheaError
import pandas as pd
import pyarrow.parquet as pq
import random

from google.api_core.exceptions import PermissionDenied

from ydata.connectors import settings
from ydata.connectors.clients import gc_client
from ydata.connectors.storages import _GCS_STORAGE, _MAX_SAMPLE
from ydata.connectors.storages import _CSV, _PARQUET, _FILE_TYPES, _EXCEL
from ydata.connectors.exceptions import DataConnectorsException
from ydata.connectors import logger
from ydata.connectors.storages.base_connector import BaseConnector
from ydata.connectors.utils import create_tmp

class GCSConnector(BaseConnector):
    """
        Google Cloud storage connector leveraging Modin to deal with Big data volumes
    """
    STORAGE_TYPE = _GCS_STORAGE

    def __init__(self, project_id, gcs_credentials=None,
                 key_path=None, keyfile_dict=None,
                 encoding = 'utf-8',
                 ds=None, **kwargs):
        BaseConnector.__init__(self)
        self._filesystem = None
        self._client = None

        if ds is None:
            self._project_id = project_id
            self._gcs_credentials = gcs_credentials
            self._key_path = key_path
            self._keyfile_dict = keyfile_dict
            self._encoding = encoding

            self._scopes = kwargs.get('scopes')

            self.credentials = {
                'project_id':self._project_id,
                'gcs_credentials': self._gcs_credentials,
                'key_path':self._key_path,
                'keyfile_dict':self._keyfile_dict,
                'scopes':self._scopes,
                'encoding':self._encoding
            }
        else:
            self.credentials = ds.credentials

    @property
    def client(self):
        if self._client is None:
            self.set_client(project_id=self.credentials['project_id'],
                            key_path=self.credentials['key_path'],
                            keyfile_dict=self.credentials['keyfile_dict'],
                            scopes=self.credentials['scopes'],
                            credentials=self.credentials['gcs_credentials'])
        return self._client

    def set_client(self,
                   project_id=None,
                   key_path=None,
                   keyfile_dict=None,
                   credentials=None,
                   scopes=None):
        """
        Sets a new gc client.
        Args:
            project_id: `str`. The project if.
            key_path: `str`. The path to the json key file.
            keyfile_dict: `str`. The dict containing the auth data.
            credentials: `Credentials instance`. The credentials to use.
            scopes: `list`. The scopes.
        Returns:
            Service client instance
        """
        self._client = gc_client.get_gc_client(
            project_id=project_id,
            key_path=key_path,
            keyfile_dict=keyfile_dict,
            credentials=credentials,
            scopes=scopes,
        )

    @property
    def filesystem(self):
        self._client = self.client
        self.set_filesystem(self.credentials)
        return self._filesystem

    def set_filesystem(self,credentials):
        self._filesystem = gc_client.get_gc_filesystem(credentials)

    def set_env_vars(self):
        if self._key_path:
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = self.credentials['key_path']
        elif self.credentials['keyfile_dict']:
            create_tmp()
            with open(settings.TMP_AUTH_GCS_ACCESS_PATH, 'w') as outfile:
                json.dump(self._keyfile_dict, outfile)
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = settings.TMP_AUTH_GCS_ACCESS_PATH

    @staticmethod
    def parse_gcs_url(gcs_url):
        """
        Parses and validates a google cloud storage url.
        Returns:
            tuple(bucket_name, blob).
        """
        try:
            spec = rhea_parser.parse_gcs_path(gcs_url)
            return spec.bucket, spec.blob
        except RheaError as e:
            raise DataConnectorsException(e)

    def get_blob(self, blob, bucket_name=None):
        """
        Get a file in Google Cloud Storage.
        Args:
            blob: `str`. the path to the object to check in the Google cloud storage bucket.
            bucket_name: `str`. Name of the bucket in which the file is stored
        """
        if not bucket_name:
            bucket_name, blob = self.parse_gcs_url(blob)
    
        bucket = self.get_bucket(bucket_name)
        # Wrap google.cloud.storage's blob to raise if the file doesn't exist
        obj = bucket.get_blob(blob)
    
        if obj is None:
            raise DataConnectorsException('File does not exist: {}'.format(blob))
    
        return obj

    def get_bucket(self, bucket_name):
        """
        Gets a bucket by name.
        Args:
            bucket_name: `str`. Name of the bucket
        """
        return self.client.get_bucket(bucket_name)

    def check_blob(self, blob, bucket_name=None):
        """
        Checks for the existence of a file in Google Cloud Storage.
        Args:
            blob: `str`. the path to the object to check in the Google cloud storage bucket.
            bucket_name: `str`. Name of the bucket in which the file is stored
        """
        try:
            return bool(self.get_blob(blob=blob, bucket_name=bucket_name))
        except Exception as e:
            logger.logger.info('Block does not exist %s', e)
            return False

    def ls(self, path):
        results = self.list(key=path)
        return {'files': results['blobs'], 'dirs': results['prefixes']}

    def list(self, key, bucket_name=None, path=None, delimiter='/', blobs=True, prefixes=True):
        """
        List prefixes and blobs in a bucket.
        Args:
            key: `str`. a key prefix.
            bucket_name: `str`. the name of the bucket.
            path: `str`. an extra path to append to the key.
            delimiter: `str`. the delimiter marks key hierarchy.
            blobs: `bool`. if it should include blobs.
            prefixes: `bool`. if it should include prefixes.
        Returns:
             Service client instance
        """
        if not bucket_name:
            bucket_name, key = self.parse_gcs_url(key)

        bucket = self.get_bucket(bucket_name)

        if key and not key.endswith('/'):
            key += '/'

        prefix = key
        if path:
            prefix = os.path.join(prefix, path)
    
        if prefix and not prefix.endswith('/'):
            prefix += '/'
    
        def get_iterator():
            return bucket.list_blobs(prefix=prefix, delimiter=delimiter)
    
        def get_blobs(_blobs):
            list_blobs = []
            for blob in _blobs:
                name = blob.name[len(key):]
                size = blob.size
                if all([name, size]):
                    list_blobs.append((name, blob.size))
            return list_blobs
    
        def get_prefixes(_prefixes):
            list_prefixes = []
            for folder_path in _prefixes:
                name = folder_path[len(key): -1]
                list_prefixes.append(name)
            return list_prefixes
    
        results = {
            'blobs': [],
            'prefixes': []
        }
    
        if blobs:
            iterator = get_iterator()
            results['blobs'] = get_blobs(list(iterator))
    
        if prefixes:
            iterator = get_iterator()
            for page in iterator.pages:
                results['prefixes'] += get_prefixes(page.prefixes)
    
        return results

    def _check_path(self, file_type, path):
        assert file_type in _FILE_TYPES, f"Provided file type {file_type} is not supported."

        bucket, filename = self.parse_gcs_url(path)
        extension = self.check_file_extension(filename)

        if extension != file_type and extension is not None:
            raise DataConnectorsException(f'File type {file_type} not in {_FILE_TYPES}.')

        if extension is None:
            files = self.ls(path)['files']
            file_paths = [os.path.join(path, file[0]) for file in files]
        else:
            file_paths = [path]

        return file_paths, bucket, filename

    def read_sample(self, path=None, file_type=_CSV):
        """
        Reads a subset of a file stored in a Google Storage Blob
        Args:
            path: 'str'. GS path for a file or folder
            file_type: 'str'. File type: it can be one of the following - .csv, .xlsx, .avro or parquet
        Returns: 'pd.Dataframe'. With the file data subset.
        """
        fs = self.filesystem
        file_paths, bucket, _ = self._check_path(file_type=file_type, path=path)

        try:
            if file_type == _EXCEL:
                with fs.open(file_paths[0], 'r') as f:
                    iterator = pd.read_excel(f, chunksize=_MAX_SAMPLE)
                    data = iterator.get_chunk(_MAX_SAMPLE)
            elif file_type == _PARQUET:
                dataset = pq.ParquetDataset(file_paths[0], filesystem=fs, buffer_size=1000)
                data = pd.DataFrame(dataset.read_pandas().to_pandas())
            else:
                with fs.open(file_paths[0], 'r') as f:
                    iterator = pd.read_csv(f, chunksize=_MAX_SAMPLE)
                    data = iterator.get_chunk(_MAX_SAMPLE)

        except PermissionError:
            raise logger.logger.error(DataConnectorsException(f'Its not possible to read the provided files from the S3 bucket {bucket}.'
                                          'Please revise your credentials or file path.'))
        return data

    def read_file(self, path=None, file_type=_CSV):
        """
            Reads a file from Google Storage blob.
            Args:
                file_name: `str`. Google blob/s path to be read.
            :return Modin pandas object with the data stored in a given a GCS file
            """
        fs = self.filesystem
        file_paths,_,_ = self._check_path(file_type=file_type, path=path)

        ls_data = []
        for file in file_paths:
            if file_type == _EXCEL:
                with fs.open(file, 'r') as f:
                    ls_data.append(pd.read_excel(f))
            elif file_type == _PARQUET:
                dataset = pq.ParquetDataset(file, filesystem=self.filesystem)
                ls_data.append(pd.DataFrame(dataset.read_pandas().to_pandas()))
            else:
                with fs.open(file, 'r') as f:
                    ls_data.append(pd.read_csv(f))
        try:
            dataset = pd.concat(ls_data)
        except:
            raise DataConnectorsException(f'Its not possible to read all files in the given {path}.'
                                          f'Please verify their structure')
        return dataset

    def write_to(self, dataset, path):
        bucket, filename = self.parse_gcs_url(path)
        extension = self.check_file_extension(filename)

        assert extension != _EXCEL, DataConnectorsException(f'Please provide a different file extension name. {extension} not supported.')

        try:
            if extension == _PARQUET:
                dataset.to_parquet(path)
            else:
                dataset.to_csv(path)
        except PermissionDenied:
            raise DataConnectorsException('It was not possible to write the dataset in the given path.'
                                          'Please verify your credentials.')
    
    

