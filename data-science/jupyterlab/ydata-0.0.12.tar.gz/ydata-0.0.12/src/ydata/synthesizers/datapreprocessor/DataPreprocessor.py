import numpy as np
import pandas as pd
import logging
import re

#from pyspark import SparkConf
#from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from sklearn.preprocessing import LabelEncoder
from sklearn.mixture import GaussianMixture
from sklearn.utils import parallel_backend

from joblibspark import register_spark

LIKELY_CAT_RATIO = 0.015

class Preprocessor(object):

    def __init__(self, spark_session ,metadata, n_clusters=10, epsilon=0.005):
        self.spark = spark_session
        self.metadata = metadata
        self.categorical_cols = metadata['categorical_cols']
        self.continuous_cols = metadata['continuous_cols']
        self.ordinal_cols = metadata['ordinal_cols']
        self.cols_metadata = metadata['columns']
        self.n_clusters= n_clusters
        self.epsilon = epsilon
        self.pipeline = None

    def __fit_categorical(self, data):
        logging.info("Start the process of encoding the categorical variables.")

        if self.pipeline is None:
            encoders = {}
        else:
            encoders = self.pipeline

        register_spark()

        with parallel_backend('spark'):
            if len(self.ordinal_cols) > 0:
                for col in self.ordinal_cols:
                    encoder = LabelEncoder()
                    current = data.select(col).toPandas()
                    model = encoder.fit(current)
                    encoders[col] = {
                                     'model': model,
                                     'output_info': [(1, 'softmax')]
                                     }

            if len(self.categorical_cols) > 0:
                for col in self.categorical_cols:
                    encoder = LabelEncoder()
                    current = data.select(col).toPandas()
                    model = encoder.fit(current)
                    encoders[col] = {
                        'model': model,
                        'output_info': [(self.cols_metadata[col]['size'], 'softmax')], # if one-hot --> [(self.cols_metadata[col]['size'], 'softmax')]
                    }

        self.pipeline = encoders

    #@ignore_warnings(category=ConvergenceWarning)
    def __fit_continous(self, data):
        logging.info('Start fitting encoders for continuous columns.')

        if self.pipeline is None:
            encoders = {}
        else:
            encoders = self.pipeline

        if len(self.continuous_cols) > 0:
            for col in self.continuous_cols:
                gmm = GaussianMixture(
                    self.n_clusters
                )
                current = data.select(col).toPandas()
                model = gmm.fit(current)
                # [TO-CHECK] Not used, do we want to keep it?
                #components = gmm.weights_ > self.epsilon
                #num_components = components.sum()

                encoders[col] = {
                                'model': model,
                                #'components': components,
                                'output_info': [(1, 'tanh'), (self.n_clusters, 'softmax')],
                                'output_dimensions': 1 + self.n_clusters,
                                 }

        self.pipeline = encoders

    def fit(self, data):
        self.output_info = []
        self.__fit_categorical(data)
        self.__fit_continous(data)

        info = []
        for k, v in self.pipeline.items():
            for item in v['output_info']:
                info.append(item)

        self.output_info = info
        return

    def __transform_categorical(self, data):
        register_spark()
        with parallel_backend('spark'):
            for col in self.categorical_cols + self.ordinal_cols:
                current = data.select(col).toPandas()
                try:
                    encoded = self.pipeline[col]['model'].transform(current).toarray()
                except:
                    encoded = self.pipeline[col]['model'].transform(current).reshape(-1,1)
                self.transformed_data.append(encoded)

    def __transform_continuous(self, data):
        with parallel_backend('spark'):
            for col in self.continuous_cols:
                model = self.pipeline[col]['model']
                # [TO-CHECK] Use only one of toarray() or np.array across all the script to be consequent
                current = np.array(data.select(col).collect())
                means = model.means_.reshape((1, self.n_clusters))
                stds = np.sqrt(model.covariances_).reshape((1, self.n_clusters))
                features = (current - means) / (4 * stds)
                probs = model.predict_proba(current)
                argmax = np.argmax(probs, axis=1)

                idx = np.arange((len(features)))
                features = features[idx, argmax].reshape([-1, 1])

                features = np.clip(features, -.99, .99)

                # [TO-CHECK] Use only one of append() or += across all the script to be consequent
                self.transformed_data += [features, probs]

    #@ignore_warnings(category=ConvergenceWarning)
    def transform(self, data):
        self.columns = data.columns
        # [TO CHECK] Transform saves data in object while other methods return the data too
        self.transformed_data = []
        self.__transform_categorical(data)
        self.__transform_continuous(data)
        final_data = np.concatenate(self.transformed_data, axis=1).astype(float)
        self.output_dim = final_data.shape[1]
        return final_data

    @staticmethod
    def __correct_data_format(data, metadata):
        for col, val in metadata.items():
            if val['type'] == 'CONTINUOUS':
                if val['n_decimals'] == -1:
                    data[col] = data[col].astype('int32')
                else:
                    data[col] = round(data[col], val['n_decimals'])

            if val['type'] == 'CATEGORICAL' or val['type'] == 'CATEGORICAL':
                if val['format'] == 'int':
                    data[col] = data[col].astype('int32')
        return data

    def inverse_transform(self, data, sigma = None):
        #o que preciso para fazer o inverse transform
        pipeline = self.pipeline

        st = 0

        data_t = []
        for col in self.ordinal_cols:
            current = data[:, st:st + 1]
            st += 1
            data_t.append(self.pipeline[col]['model'].inverse_transform(current.astype('int')).reshape(-1,1))

        for col in self.categorical_cols:
            current = data[:, st:st + 1] # if one-hot --> self.cols_metadata[col]['size']]
            st += 1 # if one-hot --> self.cols_metadata[col]['size']
            data_t.append(self.pipeline[col]['model'].inverse_transform(current.astype('int')).reshape(-1,1))

        for col in self.continuous_cols:
            #Inserir aqui o round ou clip ou o round
            u = data[:, st]
            v = data[:, st + 1:st + 1 + self.n_clusters]

            if sigma is not None:
                sig = sigma[st]
                u = np.random.normal(u, sig)

            u = np.clip(u, -1, 1)
            st += 1 + self.n_clusters
            means = self.pipeline[col]['model'].means_.reshape([-1])
            stds = np.sqrt(self.pipeline[col]['model'].covariances_).reshape([-1])
            p_argmax = np.argmax(v, axis=1)
            std_t = stds[p_argmax]
            mean_t = means[p_argmax]
            tmp = u * 4 * std_t + mean_t

            data_t.append(tmp.reshape(-1,1))

        data_t = np.concatenate(data_t, axis=1)
        data_t = pd.DataFrame(data_t, columns=self.ordinal_cols+self.categorical_cols+self.continuous_cols)
        data_t = data_t[self.columns]

        return self.__correct_data_format(data_t, self.metadata['columns'])

class DataPreprocessor(object):
    """
    input: Dataset to be pre-processed in right format to be feed into Synthetic Data Generator

    Categorical columns are encoded using OneHotEncoder
    Continuous columns are processed with Baysian Gaussian Mixture and normalized to a scalar between [0,1]
    Ordinal columns are encoded using LabelEncoder

    """

    def __init__(self, spark):
        self.spark = spark

    def __correct_data_types(self, data, col_name):
        from pyspark.sql.types import FloatType

        def blank_as_null(x):
            return F.when(F.col(x) != "", F.col(x)).otherwise(None)

        # Not used, want to keep?
        def na_as_null(x):
            return F.when(F.col(x) != "NA", F.col(x)).otherwise(None)

        columns = data.columns
        idx = columns.index(col_name)

        if data.dtypes[idx][1] == 'string':
            regx_pattern = "((([\d]{4}[-:\/\s][\d]{2}[-:\/\s][\d]{2})|" \
                           "([\d]{2}[-:\/\s][\d]{2}[-:\/\s][\d]{4}))|" \
                           "(([\d]{2})[-:\/\s](?:Jan|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)([-:\/\s][\d]{4})))"


            # check whether the string includes a datetime format
            data_aux = data.withColumn('aux_date', F.when(F.col(col_name).rlike(regx_pattern), 1).otherwise(0))
            # If doesn't contain date format try to cast to float (if does, leave it as string)
            if data_aux.select('aux_date').groupBy().sum().collect()[0][0] == 0:
                try:
                    # Test if casting to float is possible
                    isfloat = float(data_aux.select(col_name).take(1)[0][col_name])
                    try:
                        data = data.withColumn(col_name, blank_as_null(col_name)) \
                                             .withColumn(col_name, F.col(col_name).cast(FloatType()))
                    except Exception as e:
                        print(e)
                        logging.critical('Not possible to cast data type to a IntegerType of FloatType.')
                except Exception as e:
                    # If not possible casting at least convert blanks to nulls
                    try:
                        data = data.withColumn(col_name, blank_as_null(col_name))
                    except Exception as e:
                        logging.critical('Not possible to cast data type to a IntegerType of FloatType.')
        return data

    #@ignore_warnings(category=TypeError)
    def replace_missing_val_cont(self, data, cont_cols):
        # Works for a regular dataset
        # Implement for a time-series dataset
        fill_median = {col: self.metadata['columns'][col]['summary']['median'] for col in cont_cols}
        data = data.fillna(fill_median)
        return data

    #@ignore_warnings(category=TypeError)
    def replace_missing_val_cat(self, data, cat_cols):
        fill_max = {col: self.metadata['columns'][col]['summary']['max'] for col in cat_cols}
        data = data.fillna(fill_max)
        return data

    def replace_missing_val(self, data):
        def get_null_column_names(df):
            column_names = []
            for col_name in df.columns:
                count_nan = df.select(
                    F.count(F.when(F.isnan(col_name) | F.col(col_name).isNull(), col_name)).alias(col_name)).first()[0]

                if count_nan > 0:
                    column_names.append(col_name)
            return column_names

        missingval_cols = get_null_column_names(data)
        missing_cont_cols = [col for col in self.metadata['continuous_cols'] if col in missingval_cols]

        # Replace values in cont cols
        if len(missing_cont_cols) > 0:
            print('Continous ...')
            data = self.replace_missing_val_cont(data, missing_cont_cols)

        # Replace values in all the rest of the cols
        if len(missingval_cols) - len(missing_cont_cols) > 0:
            print('Categorical...')
            data = self.replace_missing_val_cat(data, list(set(missingval_cols) - set(missing_cont_cols)))

        return data

    def metadata_learner(self, data, cat_cols, cont_cols, ord_cols):
        """
        Method that extracts the summmarized information from the input dataset
        Returns A dictionary with the summarized information extracted from a given dataset
        -------
        """
        def is_likely_cat(col_data, unique_vals, unique_vals_ct):
            regex = re.compile('[@_!#$%^&*()<>?/\|}{~:]')
            #result = False
            for val in unique_vals:
                val_str = str(val[0])
                # This serves for ids, dates (TODO: check for letters to make it categorical)
                # --> What if continuous fields have some fields as string? Replace
                if(regex.search(val_str) is not None):
                    result = True
                    return result
                elif (val_str.count('-') > 1):
                    result = True
                    return result
            result = 1. * unique_vals_ct / col_data.count() < LIKELY_CAT_RATIO
            return result
            

        def extract_stats(data, col_name, type):
            if type == 'CONTINUOUS':
                stats = data.agg(F.min(F.col(col_name)).alias('min'),
                                      F.max(F.col(col_name)).alias('max'),
                                      F.mean(F.col(col_name)).alias('mean'),
                                      F.stddev(F.col(col_name)).alias('std')).toPandas().to_dict()
                stats['median'] = {0: data.approxQuantile(col_name, [0.5], 0.25)[0]}
            else:
                stats = data.agg(F.min(F.col(col_name)).alias('min'),
                                      F.max(F.col(col_name)).alias('max'),
                                      F.mean(F.col(col_name)).alias('mean'),
                                      F.stddev(F.col(col_name)).alias('std')).toPandas().to_dict()
            return stats


        logging.info("Starting the dataset preprocessing. Metadata extraction...")

        data_formats = {k:v for k,v in data.dtypes}
        df_metadata = {}
        df_metadata['columns'] = {}

        # Check if any col is not within passed ord, cat or cont cols
        missing_cols = list(set(data.columns)-set(ord_cols+cat_cols+cont_cols))

        for col_name in data.columns:
            col_info = {}
            # If mistakenly read as string correct to float
            data = self.__correct_data_types(data, col_name)
            col_data = data.select(col_name)

            # Calculate different number of values if needed
            if col_name in ord_cols + cat_cols:
                unique_vals = col_data.distinct().collect()
                unique_vals_ct = len(unique_vals)
            likely_cat = False

            # Iterate over columns missing to be assigned a type of col
            if col_name in missing_cols:
                unique_vals = col_data.distinct().collect()
                unique_vals_ct = len(unique_vals)
                # If col values have special characters, col is assigned as categorical
                if is_likely_cat(col_data, unique_vals, unique_vals_ct):
                    cat_cols.append(col_name)
                else:
                    cont_cols.append(col_name)

            # Enrich col_info
            if col_name in ord_cols:
                col_info['type'] = 'ORDINAL'
                col_info['size'] = unique_vals_ct
                col_info['format'] = data_formats[col_name]
            elif col_name in cat_cols:
                col_info['type'] = 'CATEGORICAL'
                col_info['size'] = unique_vals_ct
                col_info['format'] = data_formats[col_name]
            else:
                col_info['type'] = 'CONTINUOUS'
                col_info['n_decimals'] = str(col_data.take(1)[0]).find('.')
                col_info['format'] = data_formats[col_name]

            # Add stats to metadata for the column
            stats = extract_stats(col_data, col_name, col_info['type'])
            col_info['summary'] = {k: v[0] for k, v in stats.items()}
            df_metadata['columns'][col_name] = col_info

        df_metadata['categorical_cols'] = cat_cols
        df_metadata['continuous_cols'] = cont_cols
        df_metadata['ordinal_cols'] = ord_cols
        self.metadata = df_metadata

    def fit_transform(self, data, cat_cols=[], cont_cols=[], ord_cols=[]):
        # Get metadata of columns
        self.metadata_learner(data, cat_cols, cont_cols, ord_cols)

        logging.info("Start missing data preprocessing...")
        data = self.replace_missing_val(data)

        self.preprocessor = Preprocessor(self.spark, self.metadata)
        self.preprocessor.fit(data)
        data = self.preprocessor.transform(data)

        return data
