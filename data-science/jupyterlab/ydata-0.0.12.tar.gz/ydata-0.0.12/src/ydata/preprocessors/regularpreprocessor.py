from __future__ import absolute_import, division, print_function

from warnings import simplefilter

import pandas as pd
import numpy as np
from sklearn.exceptions import ConvergenceWarning
from sklearn.mixture import BayesianGaussianMixture
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import IsolationForest

from ydata.preprocessors.basepreprocessor import Basepreprocessor
from ydata.synthesizers.utils.transformations import skewness

class Regularpreprocessor(Basepreprocessor):
    #Pipeline is defined in the base preprocessor
    def __init__(self, metadata, n_clusters=10, epsilon=0.005):
        super().__init__(metadata)
        self.variables = metadata.variables
        self.n_clusters = n_clusters
        self.epsilon = 0.005

    def _missing_val(self, df: pd.DataFrame):
        """ Dataframe missing values inputation
        Parameters
        ----------
        df (pd.Dataframe): Pandas Dataframe with the dataset
        Returns 
        df (pd.Dataframe): Update with the missing values inputed
        -------
        """
        missingval_var = self.metadata.missingval_cols
        #Implement here a method for the missing data imputation
        return  df
    
    def _outliers(self, df: pd.DataFrame, return_outliers=False):
        """ Check the presence of outlier observations in the datasets
        Parameters
        df (pd.dataframe): The dataset as a Pandas dataframe
        return_outliers(bool): Whether or not a Pandas dataframe containing the detected outliers is returned
        Returns 
        outliers (pd.dataframe): A dataframe containing the identified outliers
        -------
        """
        outliers_model = IsolationForest(max_samples="auto",
                                         random_state=np.random.RandomState(42))

        outliers_model.fit(df.values)
        return 


    def _skewness(self, col, data):
        result, t_data = skewness(col, data)
        self.pipeline['transformations'][col].append(result)
        return t_data

    def _fit_continuous(self, col, data, bayes=True):
        #Ignore the convergence warnings
        simplefilter("ignore", category=ConvergenceWarning)
        skewed_variables = self.metadata.skewed_variables

        if col in skewed_variables:
            data = self._skewness(col, data)
        else:
            data = data.values.reshape(-1,1)

        if bayes:
            gm = BayesianGaussianMixture(
                self.n_clusters,
                weight_concentration_prior_type='dirichlet_process',
                weight_concentration_prior=0.001,
                n_init=1
            )
            gm.fit(data)
            components = gm.weights_ > self.epsilon
            num_components = components.sum()
        #Add here GaussianMixture logic

            result = {
                'model': gm,
                'components': components,
                'output_info': [(1, 'tanh'), (num_components, 'softmax')],
                'output_dimensions': 1 + num_components,
                'type': 'GaussianMixture'
            }

            self.pipeline['transformations'][col].append(result)

    def _fit_discrete(self, col, data):
        encoder = OneHotEncoder(sparse=False)
        encoder.fit(data.values.reshape(-1,1))
        categories = len(encoder.categories_[0])

        result = {
            'model': encoder,
            'output_info': [(categories, 'softmax')],
            'output_dimensions': categories,
            'type': 'encoder'
        }

        self.pipeline['transformations'][col].append(result)
        return

    def _transform_discrete(self, transf_meta, data):
        for transformation in transf_meta:
            if transformation['type'] == 'encoder':
                encoder = transformation['model']
                data = encoder.transform(data)
            else:
                raise Exception('Not a valid transformation for discrete variables.')
        return data

    def _transform_continuos(self, transf_meta, data):
        for transformation in transf_meta:
            if transformation['type'] == 'skewness':
                model = transformation['model']
                data = model.transform(data)
            else:
                components = transformation['components']
                model = transformation['model']

                means = model.means_.reshape((1, self.n_clusters))
                stds = np.sqrt(model.covariances_).reshape((1, self.n_clusters))
                features = (data - means) / (4 * stds)

                probs = model.predict_proba(data)

                n_opts = components.sum()
                features = features[:, components]
                probs = probs[:, components]

                opt_sel = np.zeros(len(data), dtype='int')
                for i in range(len(data)):
                    pp = probs[i] + 1e-6
                    pp = pp / pp.sum()
                    opt_sel[i] = np.random.choice(np.arange(n_opts), p=pp)

                idx = np.arange((len(features)))
                features = features[idx, opt_sel].reshape([-1, 1])
                features = np.clip(features, -.99, .99)

                probs_onehot = np.zeros_like(probs)
                probs_onehot[np.arange(len(probs)), opt_sel] = 1
                data = [features, probs_onehot]
        return data

    def fit_transform(self, df: pd.DataFrame, fitting=True):
        """Transform human-readable data into synthesizer feedable information.
        Args:
            df(pandas.DataFrame): Data to transform.
            fitting(bool): Whether or not to update self.metadata.
        Returns:
            pandas.DataFrame: Model features
        Returns
        -------
        """
        #verify if there are any missing values in the dataset
        if not isinstance(df, pd.DataFrame):
            df = pd.DataFrame(df)

        #self._outliers(df)

        if self.metadata.n_missingval_cols > 0:
            df = self._missing_val(df)

        #dropping any duplicate records
        df = df.drop_duplicates()

        #Fitting trasnformations to data in each dataset variables
        for col in self.variables:
            #check if it's a variable with skewness
            if col in (self.metadata.categorical+self.metadata.boolean):
                self._fit_discrete(col, df[col])
            elif col in self.metadata.continous:
                # Tranform variables that are highly skewed
                self._fit_continuous(col, df[col])

        # Starting here the Transform fase
        transformed_df=[]

        for col, transformations in self.pipeline['transformations'].items():
            column_data = df[[col]].values
            #Prosseguir a partir daqui a lógica                
            if col in (self.metadata.categorical+self.metadata.boolean):
                transformed_df.append(self._transform_discrete(transformations, column_data))
            else:
                transformed_df+=(self._transform_continuos(transformations, column_data))

        return np.concatenate(transformed_df, axis=1).astype(float)

    def _inverse_discrete(self, transf_meta, data):
        for transformation in transf_meta:
            if transformation['type'] == 'encoder':
                encoder = transformation['model']
                data = encoder.inverse_transform(data)
            else:
                raise Exception('Not a valid transformation for discrete variables.')
        return data.reshape(-1,1)
 
    def _inverse_continous(self, transf_meta, data):
        for transformation in reversed(transf_meta):
            model = transformation['model']
            if transformation['type'] == 'GaussianMixture':
                components = transformation['components']

                u = data[:, 0]
                v = data[:, 1:]

                u = np.clip(u, -1, 1)
                v_t = np.ones((len(data), self.n_clusters)) * -100
                v_t[:, components] = v
                v = v_t
                means = model.means_.reshape([-1])
                stds = np.sqrt(model.covariances_).reshape([-1])
                p_argmax = np.argmax(v, axis=1)
                std_t = stds[p_argmax]
                mean_t = means[p_argmax]
                data = u * 4 * std_t + mean_t
            elif transformation['type'] == 'skewness':
                try:
                    data = model.inverse_transform(data)
                except:
                    data = model.inverse_transform(data.reshape(-1, 1))
        return data.reshape(-1,1)

    def inverse_transform(self, data):
        assert self.pipeline is not None, Exception('Please provide a valid metadata object. It must include a Pipeline object')

        start = 0
        output = []
        column_names = []

        for col, transformations in self.pipeline['transformations'].items():
            dimensions = 1
            if len(transformations) > 0:
                dimensions = transformations[-1]['output_dimensions']
                cols_data = data[:, start:start+dimensions]

                if col in (self.metadata.categorical+self.metadata.boolean):
                    output.append(self._inverse_discrete(transformations, cols_data))
                else:
                    output.append(self._inverse_continous(transformations, cols_data))
            else:
                cols_data = data[:, start:start + dimensions]
                output.append(cols_data)

            column_names.append(col)
            start += dimensions

        assert len(output) == len(self.metadata.variables), "Something went wrong. Please verify your input."

        #Extract the number of decimal so we can replicate here
        output = np.column_stack(output)
        return pd.DataFrame(output, columns=self.metadata.variables)

if __name__ == '__main__':

    from pandas_profiling.profile_report import ProfileReport
    from data_utils.metadata import Metadata

    cols = ['age', 'workclass', 'fnlwgt', 'education', 'educational-num', 'marital-status', 'occupation',
            'race', 'gender', 'capital-gain', 'capital-loss', 'hours-per-week', 'native-country', 'income']

    df = pd.read_csv('/home/fabiana/Documents/YData/Useful projects/synthpop/data/census.csv', names=cols)

    metadata = Metadata(ProfileReport(df).get_description())

    report_html =  ProfileReport(df).to_html()
    with open('census_report.html', 'w') as f:
        f.write(report_html)

    #Start the preprocessor test
    preprocessor = Regularpreprocessor(metadata=metadata)
    tf_data = preprocessor.fit_transform(df)

    org_data = preprocessor.inverse_transform(tf_data)

    #Fazer as comparações entre origem e após transformação
    print(df.describe()-org_data.describe())
    print('Preprocessing tests')
