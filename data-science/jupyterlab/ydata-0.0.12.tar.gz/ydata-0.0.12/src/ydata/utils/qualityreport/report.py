"""
    YData report generation class.
"""

from __future__ import absolute_import, division, print_function

import pandas as pd

from datetime import datetime
from pandas_profiling import ProfileReport

class Report:

    def __init__(self):
        self.creation_date = datetime.utcnow()
        self.report_html = None
        self.report = None

    def _html_exploratory(self, df: pd.DataFrame, name):
        """
        Args:
            df: 'pd.Dataframe'.Receives the dataset to be returned the exploratory data analysis
            name: 'str'. String with the report title.
        Returns: string with the html content for the report
        """
        html = ''
        if self.report is None:
            self.report = ProfileReport(df, title=name, html={'style': {'full_width': True}, 'navbar_show': False})

        html = self.report.to_html()
        return html

    def _html_minimal_exploratory(self, df: pd.DataFrame, name):
        """
        Generates a report in html format. This is a lighter version of the exploratory data analysis without correlation computations.
        Args:
            df: 'pd.Dataframe'. A dataframe with the dataset to analyzed for report generation.
            name: 'str'. String with the report title.

        Returns: 'str'. A string with the report html content.
        """
        if self.report is None:
            self.report = ProfileReport(df, minimal=True,title=name, html={'style': {'full_width': True}, 'navbar_show': False})

        html = self.report.to_html()
        return html

    def _html_syntheticdata_quality(self, df: pd.DataFrame, synth_df: pd.DataFrame):
        """
        Method to build and render the html with the report regarding the generated dataset overall quality.
        Args:
            df: 'pd.Dataframe'. Provided dataset that was synthesized.
            synth_df:  'pd.Dataframe'. Resulting synthesi

        Returns: 'str'. String with the html content for the return
        """
        html=''
        return html

    def minimal_eda(self, df: pd.DataFrame):
        """
        Args:
            df:
        Returns:
        """
        return ''

    def full_eda(self, df: pd.DataFrame):
        """
        Args:
            df:

        Returns:

        """

    def _to_pdf(self):
        """
        Returns: A pdf format report with the content of the comparision analysis between the real and synthetic datasets.
        """
        return NotImplementedError

if __name__ == '__main__':

    df = pd.read_csv('/home/fabiana/Documents/YData/Demos/adult/adult.csv')
    report = Report()
    html_report = report._html_minimal_exploratory(df=df, name='teste')

    print('Printing the report.')
    print(html_report)
