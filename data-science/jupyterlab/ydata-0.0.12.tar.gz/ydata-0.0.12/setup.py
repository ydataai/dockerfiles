from setuptools import setup, find_namespace_packages
import os
from pathlib import Path

VERSION = os.getenv('VERSION')
print('packaging with version ', VERSION)

print('packages ', find_namespace_packages('src'))

# Read the contents of README file
source_root = Path(".")
print("source root {}".format(source_root))
with (source_root / "README.md").open(encoding="utf-8") as f:
    long_description = f.read()

# Read the requirements
with (source_root / "requirements.txt").open(encoding="utf8") as f:
    requirements = f.readlines()

setup(name='ydata',
      version=VERSION,
      description='generates synthetic data from a datasource',
      author='YData',
      author_email='developers@ydata.ai',
      classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3 :: Only',
        'Topic :: Software Development :: Libraries :: Python Modules'
      ],
      keywords='data science ydata',
      url='https://github.com/ydataai/ydata',
      packages=find_namespace_packages('src'),
      package_dir={'':'src'},
      include_package_data=True,
      install_requires=requirements,
      options={"bdist_wheel": {"universal": True}})
