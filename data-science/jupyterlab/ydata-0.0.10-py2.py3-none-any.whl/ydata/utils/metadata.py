"""
    Metadata classes. Auxiliary classes to support both the
    synthesizers and data preprocessor methods
"""
import os

from enum import Enum, unique
from pandas_profiling.profile_report import ProfileReport

import pickle

@unique
class VarType(Enum):
    """The possible types of variables available in a dataset."""
    
    TYPE_CAT = "CAT"
    """A categorical variable"""

    TYPE_BOOL = "BOOL"
    """A boolean variable"""

    TYPE_NUM = "NUM"
    """A numeric variable"""

    TYPE_DATE = "DATE"
    """A date variable"""

    TYPE_URL = "URL"
    """A URL variable"""

    TYPE_COMPLEX = "COMPLEX"

    TYPE_PATH = "PATH"
    """Absolute path"""

    TYPE_FILE = "FILE"
    """File (i.e. existing path)"""

    TYPE_IMAGE = "IMAGE"
    """Images"""

    S_TYPE_UNSUPPORTED = "UNSUPPORTED"
    """An unsupported variable"""

# Temporary mapping
Boolean = VarType.TYPE_BOOL
Real = VarType.TYPE_NUM
Count = VarType.TYPE_NUM
Complex = VarType.TYPE_COMPLEX
Date = VarType.TYPE_DATE
Categorical = VarType.TYPE_CAT
Url = VarType.TYPE_URL
AbsolutePath = VarType.TYPE_PATH
FilePath = VarType.TYPE_FILE
ImagePath = VarType.TYPE_IMAGE
Generic = VarType.S_TYPE_UNSUPPORTED

class Activation(Enum):
    """
    Activivation auxiliar class
    """
    SIGMOID = 'sigmoid'
    TANH = 'tanh'
    SOFTMAX = 'softmax'

    @staticmethod
    def valid_activation(activation):
        """
        Parameters
        ----------
        object Activation type object

        Returns boolean
        -------
        """
        result = False
        if activation in [Activation.SIGMOID, Activation.TANH, Activation.SOFTMAX]:
            result = True
        return result

class Variable():
    def __init__(self, name, var_type, size, dtype=None, activation=None, stats=None, n_decimals=None, class_col=False, is_gen_flag=False):
        assert name != ''
        assert isinstance(size, int)

        if var_type == VarType.CONTINUOUS and activation is None:
            raise Exception("normalization must be set for continuous output")

        if var_type == VarType.CONTINUOUS and activation == Activation.SOFTMAX:
            raise Exception("Activation function must be eiter SIGMOID OR TANH")

        if var_type == VarType.CATEGORICAL and activation != Activation.SOFTMAX:
            raise Exception("Activation function must be SOFTMAX for this data type.")

        self.name = name
        self.feature = True
        self.add_attribute = False
        self.size = size
        self.type = var_type
        self.activation = activation
        self.detail = {'name': name,
                       'type': var_type,
                       'size': size,
                       'activation': activation,
                       'is_gen_flag': is_gen_flag}
        self.dtype = dtype
        self.stats = stats
        self.n_decimals = n_decimals
        self.class_col = class_col

    def setdetail(self, detail_tag, detail):
        """
        :param detail_tag: Variable name
        :param detail: variable dict details
        :return: None
        """
        assert detail_tag != ''
        self.detail[detail_tag] = detail
        print('Variable updated')

    def getdetail(self):
        """
        :return: Variable information
        """
        return self.detail

class Metadata():
    """
        Metadata object that will be responsible to store some 
        information related with datasets available variables
        as well as general information and applied processing methods
    """
    SKEWNESS_THRESHOLD = 20

    def __init__(self, data_describe: dict=None):
        if data_describe is not None:
            try:
                del data_describe['messages'], data_describe['package'], data_describe['scatter']
            except KeyError:
                pass
            self.detail = data_describe
            self.num_records = self.detail['table']['n']
            self.num_variables = self.detail['table']['n_var']
            self.datasource = 'Teste'

    @property
    def categorical(self):
        """
        Dataset categorical variables that have more than two classes
        Returns a property list with all the categorical cols
        -------
        """
        self._categorical = self._get_categorical()
        return self._categorical

    @property
    def boolean(self):
        """
        Dataset categorical cols that have only two values available
        Returns a property list with all the boolean cols
        -------
        """
        self._boolean = self._get_boolean()
        return self._boolean

    @property
    def continous(self):
        """
        Dataset continous cols
        Returns a property list with all the continous cols
        -------
        """
        self._continous = self._get_continous()
        return self._continous

    @property
    def variables(self):
        """
        Check dataset available variables
        Returns a list with the dataset variables
        -------
        """
        variables = []
        for k in self.detail['variables'].keys():
            variables.append(k)
        return variables

    @property
    def missingval_cols(self):
        ls_missing=[]
        variables = self.detail['variables']
        for k,v in variables.items():
            if v['n_missing'] > 0:
                ls_missing.append(k)
        return ls_missing

    @property
    def n_missingval_cols(self):
        return len(self.missingval_cols)

    @property
    def skewed_variables(self):
        ls_skewed=[]
        variables = self.detail['variables']
        for k,v in variables.items():
            try:
                if v['skewness'] > self.SKEWNESS_THRESHOLD:
                    ls_skewed.append(k)
            except:
                pass
        return ls_skewed

    def _get_categorical(self):
        ls_categorical = []
        variables = self.detail['variables']
        for k, v in variables.items():
            if v['type'].name == VarType.TYPE_CAT.name:
                ls_categorical.append(k)
        return ls_categorical

    def _get_continous(self):
        ls_continous = []
        variables = self.detail['variables']
        for k, v in variables.items():
            if v['type'].name == VarType.TYPE_NUM.name:
                ls_continous.append(k)
        return ls_continous

    def _get_boolean(self):
        ls_bool = []
        variables = self.detail['variables']
        for k, v in variables.items():
            if v['type'].name == VarType.TYPE_BOOL.name:
                ls_bool.append(k)
        return ls_bool

    def save(self, path):
        if os.path.isdir(path):
            try:
                with open(os.path.join(path, 'metadata.pickle'), 'wb') as handle:
                    pickle.dump(self, handle, protocol=pickle.HIGHEST_PROTOCOL)
            except:
                raise Exception(f'Not able to save metadata definition to the {path}.')
        else:
            raise Exception('Please provide a valid path.')

    @staticmethod
    def load(path):
        if os.path.isdir(path):
            with open(os.path.join(path, 'metadata.pickle'), 'rb') as handle:
                metadata = pickle.load(handle)
        else:
            raise Exception('Please provide a valid path.')
        return metadata