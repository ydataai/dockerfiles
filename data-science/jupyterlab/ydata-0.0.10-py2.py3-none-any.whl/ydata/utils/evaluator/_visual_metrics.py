import os
import logging
import pandas as pd
import numpy as np

import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import stats
from scipy.stats import stats

from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from ._coefficients import theils_u, correlation_ratio

def continuous_density(real, synth, xlabel: str = 'Values', ylabel: str = 'Cumulative sum', ax=None):
    x_real = np.sort(real)
    x_synth = np.sort(synth)
    y = np.arange(1, len(real) + 1) / len(real)

    ax = ax if ax else plt.subplots()[1]

    axis_font = {'size': 15}
    ax.set_xlabel(xlabel, **axis_font)
    ax.set_ylabel(ylabel, **axis_font)

    ax.grid(False)
    ax.plot(x_real, y, marker='o', linestyle='none', label='Real', ms=8, color='darkblue')
    ax.plot(x_synth, y, marker='o', linestyle='none', label='Synthetic', ms=8, color='plum')
    ax.tick_params(axis='both', which='major', labelsize=8)
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, 1.1), ncol=3)

    if isinstance(real, pd.Series) and real.dtypes == 'object':
        ax.set_xticklabels(real.value_counts().sort_index().index, rotation='vertical')

    if ax is None:
        plt.show()


def correlations(df, columns, cat_cols, return_results: bool = True, plot: bool = True, ax=None, **kwargs):
    # Pearsons for continuous-continuous correlations
    # Correlations Ratio for categorical-continuous correlations
    # Theil's for categorical-categorical correlations
    
    if plot is False:
        assert kwargs == {}
    
    cont_cols = list(set(columns) - set(cat_cols))
    corr = pd.DataFrame(index=columns, columns=columns)
    
    for i in range(0, len(columns)):
        for j in range(i, len(columns)):
            if i == j:
                corr[columns[i]][columns[j]] = 1.0
            else:
                if columns[i] in cat_cols:
                    if columns[j] in cat_cols:
                        corr[columns[j]][columns[i]] = theils_u(df[columns[i]], df[columns[j]], nan_strategy='skip')
                        corr[columns[i]][columns[j]] = theils_u(df[columns[j]], df[columns[i]], nan_strategy='skip')
                    else:
                        aux = correlation_ratio(df[columns[i]], df[columns[j]], nan_strategy='skip')
                        corr[columns[j]][columns[i]] = aux
                        corr[columns[i]][columns[j]] = aux
                else:
                    if columns[j] in cat_cols:
                        aux = correlation_ratio(df[columns[j]], df[columns[i]], nan_strategy='skip')
                        corr[columns[j]][columns[i]] = aux
                        corr[columns[i]][columns[j]] = aux
                    else:
                        aux, _ = stats.pearsonr(df[columns[i]], df[columns[j]])
                        corr[columns[i]][columns[j]] = aux
                        corr[columns[j]][columns[i]] = aux

    corr.fillna(value=np.nan, inplace=True)
    return corr


def correlation_plot(real: pd.DataFrame, synth: pd.DataFrame, plot_diff: bool = True, cont_cols: list = [], **kwargs):
    try:
        assert isinstance(real, pd.DataFrame)
        assert isinstance(synth, pd.DataFrame)
    except AssertionError as e:
        logging.error("Both the synthetic and real data provided must be as a Pandas dataframe.")
        return
    
    cat_cols = list(set(real.columns) - set(cont_cols))
    
    if plot_diff:
        fig, ax = plt.subplots(1, 3, figsize=(25, 8))
    else:
        fig, ax = plt.subplots(1, 2, figsize=(20, 8))

    r_corr = correlations(real, real.columns, cat_cols)

    s_corr = correlations(synth, real.columns, cat_cols)

    titles = ['Real data correlations', 'Synthetic data correlations']
    
    if plot_diff:
        titles += ['Correlations Difference']
        
        diff = abs(r_corr - s_corr)
        sns.set(style='white')
        cmap = sns.diverging_palette(275, 240, as_cmap=True)
        sns.heatmap(diff, ax=ax[2], cmap=cmap, vmax=.3, square=True, center=0,
                    linewidths=.5, cbar_kws={"shrink": .5}, fmt='.2f')
    
    sns.heatmap(r_corr, ax=ax[0], cmap=cmap, vmax=.3, square=True, center=0,
                linewidths=.5, cbar_kws={"shrink": .5}, fmt='.2f')
    sns.heatmap(s_corr, ax=ax[1], cmap=cmap, vmax=.3, square=True, center=0,
                linewidths=.5, cbar_kws={"shrink": .5}, fmt='.2f')
    
    for i, title in enumerate(titles):
        title_font = {'size': '20', 'pad': '30', 'fontweight': 'bold'}
        ax[i].set_title(title, **title_font)
    
    plt.tight_layout()
    plt.close()
    
    return r_corr, s_corr, diff


def numerical_encoding(df, cat_cols=[], ord_cols=[]):
    try:
        assert isinstance(df, pd.DataFrame)
    except AssertionError as e:
        logging.error('The df input object must a Pandas dataframe. This action will not be executed.')
        return
    ord_cols_val = None
    cat_cols_val = None
    dummies = None
    cont_cols = list(set(df.columns) - set(cat_cols + ord_cols))
    cont_vals = df[cont_cols].values
    
    if len(ord_cols) > 0:
        ord_cols_val = df[ord_cols].values
        label_encoder = LabelEncoder
        ord_encoded = label_encoder.fit_transform(ord_cols_val)
    
    if len(cat_cols) > 0:
        cat_cols_val = df[cat_cols].values
        hot_encoder = OneHotEncoder()
        cat_encoded = hot_encoder.fit_transform(cat_cols_val).toarray()
        
        dummies = []
        for i, cat in enumerate(hot_encoder.categories_):
            for j in cat:
                dummies.append(cat_cols[i] + '_' + str(j))
    
    if ord_cols_val is not None and cat_cols_val is not None:
        encoded = np.hstack([cont_vals, ord_encoded, cat_encoded])
        columns = cont_cols + ord_cols + dummies
    elif cat_cols_val is not None:
        encoded = np.hstack([cont_vals, cat_encoded])
        columns = cont_cols + ord_cols + dummies
    else:
        encoded = cont_vals
        columns = cont_cols
    
    return pd.DataFrame(encoded, columns=columns), dummies


def mean_absolute_percentage_error(y_true: np.ndarray, y_pred: np.ndarray):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true))
