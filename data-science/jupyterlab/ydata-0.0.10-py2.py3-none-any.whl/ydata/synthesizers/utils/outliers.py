"""
Method to identify dataset outliers. Method used by the preprocessor methods
"""
import modin.pandas as pd

def outliers(df: pd.DataFrame, return_outliers: bool=False, time_series: bool=False):
    """
    Parameters
    ----------
    df: A pandas dataframe to extract the outliers from
    return_outliers: bool True if outliers are to be kept or False if to be removed 
    time_series: bool True if outliers detection for time-series dataset

    Returns dataframe with the identified outlier processed
    -------
    """
    return 
