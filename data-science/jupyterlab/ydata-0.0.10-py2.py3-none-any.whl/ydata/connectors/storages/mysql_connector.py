"""
RDBMS Connectors - Supports the following list of databases:
- MYSQL
"""

from sqlalchemy import inspect
from sqlalchemy.exc import DatabaseError, ProgrammingError
import pandas as pd

from ydata.connectors import BaseConnector
from ydata.connectors import _RDBMS_STORAGE
from ydata.connectors.clients.rdbms_client import create_db_engine
from ydata.connectors import DataConnectorsException


class MySQLConnector(BaseConnector):
    """
        RDMS databases connectors
    """
    STORE_TYPE = _RDBMS_STORAGE

    def __init__(self, ds=None,**kwargs):
        BaseConnector.__init__(self)

        if ds == None:
            self._username = kwargs.get('username')
            self._server = kwargs.get('server')

            assert (self._server and self._username) is not None, \
                "Invalid provided credentials"
            assert (self._server and self._username) != '', \
                "Invalid provided credentials"

            self._database_type = 'mysql'

            self.credentials = {
                'username': self._username,
                'password': kwargs.get('password'),
                'server': self._server,
                'database_type': 'mysql'
            }
            try:
                self._database_name = kwargs.get('database_name')
            except:
                self._database_name = None

            try:
                self._port = kwargs.get('port')
            except:
                self._port = None

            self.credentials['database_name'] = self._database_name
            self.credentials['port'] = self._port
        else:
            self.credentials = ds.credentials
            self._client = ds.client
        #Setting the environment variables for the storage

    @property
    def engine(self):
        #Start querying engine or getting connection
        return self.set_engine(username=self.credentials['username'],
                               password=self.credentials['password'],
                               server_name=self.credentials['server'],
                               port = self.credentials['port'],
                               database_type=self.credentials['database_type'],
                               database_name=self.credentials['database_name'])

    def set_engine(self, username, password, server_name, port, database_type, database_name=None):
        try:
            engine = create_db_engine(username=username,
                                      password=password,
                                      server_name=server_name,
                                      port=port,
                                      database_type=database_type,
                                      database_name=database_name)
        except:
            raise DataConnectorsException('Not possible to connect to the given storage. Please review the provided credentials.')
        return engine

    def list_databases(self, startswith=None):
        """
        Returns a list with all existing databases
        Args:
            startswith: 'str'. String to search the database which name startswith.
        Returns: A dict with the name of the databases (metadata?)
        """
        #ok here execute the query for all the existing databases
        engine = self.engine
        insp = inspect(engine)
        db_list = insp.get_schema_names()
        return db_list

    def list_tables(self, database_name):
        """
        Returns a list with all the existing tables from a provided database
        Args:
            database_name: 'str'. Database name to list the tables from.
        Returns: A list containing all the existing tables (metadata?)
        """
        engine = self.engine
        tables_list = []

        try:
            query = engine.execute(f'SHOW TABLES FROM {database_name};')
            results = query.fetchall()
            for table in results:
                tables_list.append(table[0])
        except DatabaseError:
            raise DataConnectorsException('It was not possible list tables. Confirm if the provided database exist.')
        return tables_list

    def create_database(self, database_name):
        """
        Method to create a new database if it doesn't exist.
        Args:
            database_name: 'str'. Name of the database to be created
        """
        try:
            self.engine.execute(f'CREATE DATABASE IF NOT EXISTS {database_name};')
        except DatabaseError:
            raise DataConnectorsException('It was not possible to create the database. The database already exists.')

    def get_table_schema(self, database_name, table_name):
        """
        Get the schema detail for a given table.
        Args:
            database_name: 'str'. Name of the database.
            table_name: 'str'. Name of the table to extract the metadata from

        Returns: 'list'. List of dicts with the table's metadata.
        """
        table_schema = []
        try:
            query = self.engine.execute(f'DESCRIBE {database_name}.{table_name};')
        except DatabaseError:
            raise DataConnectorsException('It was not possible to retrieve the schema of the table provided.')

        results = query.fetchall()
        for result in results:
            table_schema.append({'column_name': result[0],
                                 'column_type': result[1],
                                 'null_vals': result[2],
                                 'key': result[3],
                                 'default': result[4],
                                 'extra': result[5]})
        return table_schema

    def write_to_table(self, df, table_name, index_label=None, schema=None):
        """
        Create a new table from a given pd.Dataframe.
        Args:
            df: 'pd.Dataframe'. Dataframe to be copied into a new table
        """
        #pronto há mais esta aqui agora é verificar se fica bem feito
        assert self._database_name != None, "Database must be defined at the connector level."

        try:
            #create here a new engine será?
            print('Teste')
            df.to_sql(table_name, self.engine, if_exists='fail')
        except:
            raise DataConnectorsException(f'It was not possible to write the dataframe into {table_name}.')

    def query(self, query, index_col=None):
        """
        Extract data from a database through a query
        Args:
            query:'str'. Receives a query as an string. 

        Returns: 'pd.Dataframe'. Pandas dataframe with the content resulting from the query
        """
        try:
            df = pd.read_sql(query, con=self.engine, index_col=index_col)
        except ProgrammingError:
            raise DataConnectorsException('I was not possible to execute the provided query. No database selected.')
        return df

if __name__ == '__main__':

    #Testing the data connectors
    kwargs = {
        'username': 'test',
        'password': 'testydata',
        'server': 'localhost',
        'database_type': 'mysql'
    }

    df = pd.read_csv('/home/fabiana/Documents/data.csv', index_col=0)

    conn = MySQLConnector(**kwargs)
    list_db = conn.list_databases()
    #conn.get_table_schema(database_name='YDATA', table_name='test_csv')
    #conn.write_to_table(df=df, table_name='test_csv')
    #query a table from a database
    result = conn.query('SELECT * FROM YDATA.test_csv')
    print('Testing the RDBMS')