import os
from pathlib import Path

import pickle

import numpy as np
import torch
from torch import optim
from torch.nn import functional
import h2o
from sklearn.model_selection import train_test_split

from tqdm import tqdm

from ydata.synthesizers.regular.__discriminator import Discriminator
from ydata.synthesizers.regular.__generator import Generator
from ydata.synthesizers.regular.__conditional import ConditionalGenerator
from ydata.preprocessors.regularpreprocessor import Regularpreprocessor
from ydata.utils import Metadata, Evaluator

from pandas_profiling import ProfileReport

class _Sampler(object):
    """
    Method responsible to generate the dataset samples
    """
    def __init__(self, data, transformations):
        super(_Sampler, self).__init__()
        self.data = data
        self.sampler = []
        self.n = len(data)

        st = 0
        skip = False
        for col, transf in transformations.items():
            for item in transf[-1]['output_info']:
                if item[1] == 'tanh':
                    st += item[0]
                    skip = True
                elif item[1] == 'softmax':
                    if skip:
                        skip = False
                        st += item[0]
                        continue
                    ed = st + item[0]
                    tmp = []
                    for j in range(item[0]):
                        tmp.append(np.nonzero(data[:, st + j])[0])
                    self.sampler.append(tmp)
                    st = ed
                else:
                    assert 0
        assert st == data.shape[1]

    def sample(self, n, col, opt):
        if col is None:
            idx = np.random.choice(np.arange(self.n), n)
            return self.data[idx]
        idx = []
        for c, o in zip(col, opt):
            idx.append(np.random.choice(self.sampler[c][o]))
        return self.data[idx]

#Loss function WGAN with gradient penalty
def _calc_gradient_penalty(netD, real_data, fake_data, device='cpu', pac=10, lambda_=10):
    alpha = torch.rand(real_data.size(0) // pac, 1, 1, device=device)
    alpha = alpha.repeat(1, pac, real_data.size(1))
    alpha = alpha.view(-1, real_data.size(1))

    interpolates = alpha * real_data + ((1 - alpha) * fake_data)

    disc_interpolates = netD(interpolates)

    gradients = torch.autograd.grad(
        outputs=disc_interpolates, inputs=interpolates,
        grad_outputs=torch.ones(disc_interpolates.size(), device=device),
        create_graph=True, retain_graph=True, only_inputs=True)[0]

    gradient_penalty = (
        (gradients.view(-1, pac * real_data.size(1)).norm(2, dim=1) - 1) ** 2).mean() * lambda_
    return gradient_penalty

class RegularSynthesizer(object):

    def __init__(self, embedding_dim=128, gen_dim=(256, 256), dis_dim=(256, 256),l2scale=1e-6, batch_size=150, epochs=500):
        self.embedding_dim = embedding_dim
        self.gen_dim = gen_dim
        self.dis_dim = dis_dim

        self.l2scale = l2scale
        self.batch_size = batch_size
        self.epochs = epochs
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    def _apply_activate(self,data):
        data_t = []
        st = 0
        for col, transf in self.preprocessor.pipeline['transformations'].items():
            for item in transf[-1]['output_info']:
                if item[1] == 'tanh':
                    ed = st + item[0]
                    data_t.append(torch.tanh(data[:, st:ed]))
                    st = ed
                elif item[1] == 'softmax':
                    ed = st + item[0]
                    data_t.append(functional.gumbel_softmax((data[:, st:ed]), tau=0.2))
                    st = ed
                else:
                    assert 0
        return torch.cat(data_t, dim=1)    

    def _cond_loss(self, data, c, m):
        loss = []
        st = 0
        st_c = 0
        skip = False
        for col, transf in self.preprocessor.pipeline['transformations'].items():
            for item in transf[-1]['output_info']:
                if item[1] == 'tanh':
                    st += item[0]
                    skip = True

                elif item[1] == 'softmax':
                    if skip:
                        skip = False
                        st += item[0]
                        continue

                    ed = st + item[0]
                    ed_c = st_c + item[0]
                    tmp = functional.cross_entropy(
                        data[:, st:ed],
                        torch.argmax(c[:, st_c:ed_c], dim=1),
                        reduction='none'
                    )
                    loss.append(tmp)
                    st = ed
                    st_c = ed_c
    
                else:
                    assert 0
    
        loss = torch.stack(loss, dim=1)

        return (loss * m).sum() / data.size()[0]

    def fit(self, org_data, target_col=None, lr_g=2e-4, lr_d=2e-4):
        metadata = Metadata(ProfileReport(org_data.reset_index().drop('index', axis=1)).get_description())

        self.preprocessor = Regularpreprocessor(metadata=metadata)
        data = self.preprocessor.fit_transform(org_data)

        data_sampler = _Sampler(data, self.preprocessor.pipeline['transformations'])

        data_dim = data.shape[1]

        self.cond_generator = ConditionalGenerator(data, self.preprocessor.pipeline['transformations'])

        self.__generator = Generator(
            self.embedding_dim + self.cond_generator.n_opt,
            self.gen_dim,
            data_dim).to(self.device)

        self.__discriminator = Discriminator(
            data_dim + self.cond_generator.n_opt,
            self.dis_dim).to(self.device)

        #Initizalize both discriminator and generator optimizers
        optimizerG = optim.Adam(
            self.__generator.parameters(), lr=lr_g, betas=(0.5, 0.9), weight_decay=self.l2scale)
        optimizerD = optim.Adam(self.__discriminator.parameters(), lr=lr_d, betas=(0.5, 0.9))

        assert self.batch_size % 2 == 0
        mean = torch.zeros(self.batch_size, self.embedding_dim, device=self.device)
        std = mean + 1

        steps_per_epoch = len(data) // self.batch_size
        eval = []
        best_val = 0
        best_epoch = 0
        for i in tqdm(range(self.epochs), desc='Epochs'):
            for id_ in range(steps_per_epoch):
                fakez = torch.normal(mean=mean, std=std)

                condvec = self.cond_generator.sample(self.batch_size)
                if condvec is None:
                    c1, m1, col, opt = None, None, None, None
                    real = data_sampler.sample(self.batch_size, col, opt)
                else:
                    c1, m1, col, opt = condvec
                    c1 = torch.from_numpy(c1).to(self.device)
                    fakez = torch.cat([fakez, c1], dim=1)

                    perm = np.arange(self.batch_size)
                    np.random.shuffle(perm)
                    real = data_sampler.sample(self.batch_size, col[perm], opt[perm])
                    c2 = c1[perm]

                fake = self.__generator(fakez)
                fakeact = self._apply_activate(fake)

                real = torch.from_numpy(real.astype('float32')).to(self.device)

                if c1 is not None:
                    fake_cat = torch.cat([fakeact, c1], dim=1)
                    real_cat = torch.cat([real, c2], dim=1)
                else:
                    real_cat = real
                    fake_cat = fake

                y_fake = self.__discriminator(fake_cat)
                y_real = self.__discriminator(real_cat)

                loss_d = -(torch.mean(y_real) - torch.mean(y_fake))
                pen = _calc_gradient_penalty(self.__discriminator, real_cat, fake_cat, self.device)

                optimizerD.zero_grad()
                pen.backward(retain_graph=True)
                loss_d.backward()
                optimizerD.step()

                fakez = torch.normal(mean=mean, std=std)
                condvec = self.cond_generator.sample(self.batch_size)

                if condvec is None:
                    c1, m1, col, opt = None, None, None, None
                else:
                    c1, m1, col, opt = condvec
                    c1 = torch.from_numpy(c1).to(self.device)
                    m1 = torch.from_numpy(m1).to(self.device)
                    fakez = torch.cat([fakez, c1], dim=1)

                fake = self.__generator(fakez)
                fakeact = self._apply_activate(fake)

                if c1 is not None:
                    y_fake = self.__discriminator(torch.cat([fakeact, c1], dim=1))
                else:
                    y_fake = self.__discriminator(fakeact)

                if condvec is None:
                    cross_entropy = 0
                else:
                    cross_entropy = self._cond_loss(fake, c1, m1)

                loss_g = -torch.mean(y_fake) + cross_entropy

                optimizerG.zero_grad()
                loss_g.backward()
                optimizerG.step()

            if i%5==0 and i> 50:
                synth_data = self.sample(len(org_data))._to_pandas()
                cat_cols = self.preprocessor.metadata.categorical+self.preprocessor.metadata.boolean

                evaluator = Evaluator(real=org_data, synthetic=synth_data, cat_cols=cat_cols,
                                      n_samples=len(org_data))

                r_corr, s_corr, diff = evaluator.plot_correlation_differences()
                mean_corr = diff.mean().mean()

                statistical_similarity = evaluator.statistical_eval()
                num_dups = evaluator.check_realSyn_dups(return_val=False)

                score = 0.4 * (1 - mean_corr) + 0.45 * (statistical_similarity) + 0.15*(1-(num_dups/len(org_data)))

                if score > best_val:
                    print('Epoch {}: {}'.format(i, score))
                    best_val = score
                    best_epoch = i
                    eval.append({'epoch': i, 'eval': mean_corr})
                    self.save(save_dir='tmp', folder_name='epoch_{}'.format(i))

                if target_col is not None:
                    estimators_similarity = evaluator.estimator_eval(target_col=target_col)
                    #TODO integrate estimators_similarity into the evaluation process

        #TODO private funtion
        """
        import os
        import glob

        files = glob.glob('/YOUR/PATH/*')
        for f in files:
            os.remove(f)
        """
        self.load(model_dir='tmp', folder_name='epoch_{}'.format(best_epoch))
        #delete tmp folder content
        #save the model into the final model folder

    def sample(self, num_samples):
        steps = num_samples // self.batch_size +1
        data = []

        for i in range(steps):
            mean = torch.zeros(self.batch_size, self.embedding_dim)
            std = mean +1
            fakez = torch.normal(mean=mean, std = std).to(self.device)

            condvec = self.cond_generator.sample_zero(self.batch_size)
            if condvec is None:
                pass
            else:
                c1 = condvec
                c1 = torch.from_numpy(c1).to(self.device)
                fakez = torch.cat([fakez, c1], dim=1)

            fake = self.__generator(fakez)
            fakeact = self._apply_activate(fake)
            data.append((fakeact.detach().cpu().numpy()))

        data = np.concatenate(data, axis=0)
        data = data[:num_samples]
        return self.preprocessor.inverse_transform(data)

    def save(self, save_dir = 'models', folder_name= ''):
        model_path= Path(f'{save_dir}/{folder_name}')
        os.makedirs(model_path, exist_ok=True)
        torch.save(self.__generator.state_dict(), model_path/'generator.pth')
        torch.save(self.__discriminator.state_dict(), model_path/'discriminator.pth')
        with open(model_path/'dict.pkl', 'wb') as file:
            pickle.dump(self.__dict__, file, protocol=None)

    def load(self, model_dir = 'models', folder_name=''):
        model_path = Path(f'{model_dir}/{folder_name}')
        self.__dict__ = pickle.load(open(f'{model_path}/dict.pkl', 'rb'))
        self.__generator.load_state_dict(torch.load(f'{model_path}/generator.pth'))
        self.__discriminator.load_state_dict(torch.load(f'{model_path}/discriminator.pth'))