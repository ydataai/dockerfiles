import sys

from pyspark.sql import functions as F
import h2o
from h2o.automl import H2OAutoML
from sklearn.metrics import accuracy_score

def check_special_characters(val_list):
    import re
    regex = re.compile('[@_!#$%^&*()<>?/\|}{~:]')
    result = False
    for val in val_list:
        if (regex.search(str(val[0])) != None):
            result = True
            break
    return result


def check_for_letters(val_list):
    import re
    regex = re.compile('(?i)[a-z]')
    result = False
    for val in val_list:
        if (regex.search(str(val[0])) != None):
            result = True
            break
    return result


def extract_stats(data, col_name, type):
    if type == 'CONTINUOUS':
        stats = data.agg(F.min(F.col(col_name)).alias('min'),
                              F.max(F.col(col_name)).alias('max'),
                              F.mean(F.col(col_name)).alias('mean'),
                              F.stddev(F.col(col_name)).alias('std')).toPandas().to_dict()
        stats['median'] = {0: data.approxQuantile(col_name, [0.5], 0.25)[0]}
    else:
        stats = data.agg(F.min(F.col(col_name)).alias('min'),
                              F.max(F.col(col_name)).alias('max'),
                              F.mean(F.col(col_name)).alias('mean'),
                              F.stddev(F.col(col_name)).alias('std')).toPandas().to_dict()
    return stats


def metadata_learner(data, metadata: dict, columns:list, type:str = None):
    '''
    Parameters
    ----------
    metadata Receives a dictionary with the metadata from the columns in the dataset
    columns Receives the list of columns from the metadata shalle be learned
    type if type is None, then it's assumed this is a refular dataset to be preprocessed, and not a Time-Series one

    Returns a metadata dictionary
    -------
    '''
    try:
        assert type in ['attributes','features',None]
    except AssertionError as e:
        print('The value for the variable type must be one in the following list [attributes, features, None].')
        sys.exit()
    cat_columns = []
    cont_columns = []

    #Aqui fazer uma lógica de processamento
    for col_name in columns:
        col_info = {}
        #self.__correct_data_types(col_name)
        unique_vals = data.select(col_name).distinct().collect()
        unique_vals_ct = len(unique_vals)

        if check_special_characters(unique_vals) == False:
            if check_for_letters(unique_vals) == False:
                # Regex to check whether it's a data or not
                likely_cat = 1. * unique_vals_ct / data.select(col_name).count() < 0.015
            else:
                likely_cat = True

        if likely_cat:
            col_info['type'] = 'CATEGORICAL'
            col_info['size'] = unique_vals_ct
            cat_columns.append(col_name)
        else:
            col_info['type'] = 'CONTINUOUS'
            cont_columns.append(col_name)

        stats = extract_stats(data, col_name, col_info['type'])
        col_info['summary'] = {k: v[0] for k, v in stats.items()}
        col_info['missing_val'] = data.select(F.count(F.when(F.isnan(col_name) | F.col(col_name).isNull(), col_name)).alias(col_name)).first()[0]

        if type != None:
            metadata[type][col_name] = col_info
        else:
            metadata['columns'][col_name] = col_info

    metadata[type]['categorical']= cat_columns
    metadata[type]['continuous'] = cont_columns

    return metadata
