# https://github.com/DAI-Lab/CTGA

"""
The :mod:`ydata.synthesizers` module that gathers the different algorithms for data synthetization.
"""
from ydata.synthesizers.regular import RegularSynthesizer
from ydata.preprocessors.regularpreprocessor import Regularpreprocessor

__all__ = [
           'RegularSynthesizer',
           'Regularpreprocessor'
           ]