"""
    Tensorflow developed synthesizers base class
    Includes methods such as model save, model summary, noise generation and model checkpoints
"""
import pickle
import numpy as np
from tqdm import trange

import tensorflow as tf
from tensorflow.keras.callbacks import ModelCheckpoint

class BaseSynthesizer():

    def __init__(self):
        self.timeseries = False
        self.attributes = False
        self.generator = None
        self.discriminator = None

        self.batch_size = 100
        self.time = None
        self.noise_dim = 10
        self.metadata = None

    @staticmethod
    def summary(name_data_dict,
                step=None,
                types=['mean', 'std', 'max', 'min', 'sparsity', 'histogram'],
                historgram_buckets=None,
                name='summary'):
        """Summary.
        Examples
        --------
        >>> summary({'a': data_a, 'b': data_b})
        """

        def _summary(name, data):
            if data.shape == ():
                tf.summary.scalar(name, data, step=step)
            else:
                if 'mean' in types:
                    tf.summary.scalar(name + '-mean', tf.math.reduce_mean(data), step=step)
                if 'std' in types:
                    tf.summary.scalar(name + '-std', tf.math.reduce_std(data), step=step)
                if 'max' in types:
                    tf.summary.scalar(name + '-max', tf.math.reduce_max(data), step=step)
                if 'min' in types:
                    tf.summary.scalar(name + '-min', tf.math.reduce_min(data), step=step)
                if 'sparsity' in types:
                    tf.summary.scalar(name + '-sparsity', tf.math.zero_fraction(data), step=step)
                if 'histogram' in types:
                    tf.summary.histogram(name, data, step=step, buckets=historgram_buckets)

        with tf.name_scope(name):
            for name, data in name_data_dict.items():
                _summary(name, data)

    def gen_noise(self):
        """
        Method to generate the noise inputs that feed the generators
        Returns Noise or random generated tensors
        -------
        """
        noise = []
        if self.timeseries:
            features_z = tf.random.normal(shape=(self.batch_size, self.time, self.noise_dim))
            noise.append(features_z)
            if self.attributes:
                attr_z = tf.random.normal(shape=(self.batch_size, self.noise_dim))
                aux_attr_z = tf.random.normal(shape=(self.batch_size, self.noise_dim))
                noise += [attr_z, aux_attr_z]
        else:
            features_z = tf.random.normal(shape=(self.batch_size, self.noise_dim))
            noise.append(features_z)
        return noise

    def sample(self, num_samples):
        """
        Parameters
        ----------
        num_samples number of events to be synthetic generated

        Returns features if regular data synhtesizer,
                         features and attributes if time-series synthesizer
        -------
        """
        assert self.generator is not None, "Please load a trained generator or train a synthesizer."
        nround = num_samples//self.batch_size
        features_sample = []
        if self.attributes:
            attributes_sample = []

        for i in trange(nround):
            z = self.gen_noise()

            if self.attributes:
                features, attributes = self.generator(z, training=False)
                attributes_sample.append(attributes)
            else:
                features = self.generator(z, training=False)

            features_sample.append(features)

        features = np.concatenate(features_sample, axis=0)
        if self.attributes:
            attributes = np.concatenate(attributes_sample, axis=0)
            return features, attributes
        else:
            return features

    def save(self, model_dir):
        """
        Parameters
        ----------
        model_dir Save final model in a defined directory
        """
        assert self.generator is not None, \
            "You've no available Generator. Please before saving you Synthesizer, train it first."
        assert model_dir != (None, ''), \
            "You have to provided a valid directory to save your model."
