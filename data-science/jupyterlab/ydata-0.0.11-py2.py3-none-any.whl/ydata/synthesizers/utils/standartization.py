"""
Methods for data standartization.
"""