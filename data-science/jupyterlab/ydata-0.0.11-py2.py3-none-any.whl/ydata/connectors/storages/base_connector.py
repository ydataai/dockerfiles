from __future__ import absolute_import, division, print_function

from rhea import RheaError
import uuid
from datetime import datetime

from ydata.connectors.storages import _LOCAL_STORAGE, _AZURE_STORAGE, _S3_STORAGE, _GCS_STORAGE, _RDBMS_STORAGE,_STORAGE_TYPES
from ydata.connectors.storages import _CSV, _EXCEL, _PARQUET, _FILE_TYPES
#from polystores import settings
from ydata.connectors.exceptions import DataConnectorsException
from ydata.connectors.utils import get_from_env


class BaseConnector(object):
    """
    Base connectors interface
    """
    _LOCAL_STORAGE, _AZURE_STORAGE, _S3_STORAGE, _GCS_STORAGE, _STORAGE_TYPES
    STORAGE_TYPE = None
    def __init__(self):
        self.id = uuid.uuid1()
        self.creation_date = datetime.utcnow()
        
    def set_env_vars(self):
        """Set authentication and access of the current store to the env vars"""
        pass

    @property
    def is_local_store(self):
        return self.STORE_TYPE == self._LOCAL_STORAGE

    @property
    def is_s3_store(self):
        return self.STORE_TYPE == self._S3_STORAGE

    @property
    def is_azure_store(self):
        return self.STORE_TYPE == self._AZURE_STORAGE

    @property
    def is_gcs_store(self):
        return self.STORE_TYPE == self._GCS_STORAGE

    @property
    def is_rdbms_store(self):
        return self.STORAGE_TYPE == self._RDBMS_STORAGE

    @staticmethod
    def check_file_extension(filename):
        try:
            extension = filename.split('.')[1]
        except:
            extension = None                        
        return extension

    def create_ds(self, credentials):
        """
        Method to create a DataSource for a giving connector
        :return: None
        """
        #DataSource save to a giving path defined at the level of environment variables
        #DATASOURCES_PATH
        raise NotImplementedError

    def ls(self, path):
        raise NotImplementedError

    def list(self, *args, **kwargs):
        raise NotImplementedError

    def read_sample(self):
        raise NotImplementedError

    def read_file(self, path=None, file_type=_CSV):
        raise NotImplementedError

    def write_to(self, df, path, file_type=_CSV):
        raise NotImplementedError

    def get_table_schema(self, database_name, table_name):
        raise NotImplementedError

    def write_to_table(self, df, table_name, schema=None):
        raise NotImplementedError