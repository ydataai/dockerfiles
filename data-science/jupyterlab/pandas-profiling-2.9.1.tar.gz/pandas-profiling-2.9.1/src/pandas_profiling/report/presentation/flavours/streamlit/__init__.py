"""Reserved for streamlit user interface"""
