from pandas_profiling.profile_report import ProfileReport
import modin.pandas as pd

df = pd.read_csv(
    "/home/fabiana/Documents/YData/syntheticgenerators/data/diamonds/data.csv"
)
metadata = ProfileReport(df, config_file="config_dark.yaml")

html_report = metadata.to_html()

with open("./report.html", "w") as f:
    f.write(html_report)
print("Metadata calc end")
