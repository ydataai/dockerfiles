"""The controller module handles all user interaction with the package (console, jupyter, etc.)."""
