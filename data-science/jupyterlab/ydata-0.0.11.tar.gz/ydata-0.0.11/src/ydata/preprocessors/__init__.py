# https://github.com/DAI-Lab/CTGA

"""
The :mod:`ydata.preprocessors` module that gathers the different preprocessors seet for different data types
"""
from ydata.preprocessors.regularpreprocessor import Regularpreprocessor

__all__ = [
           'Regularpreprocessor',
           ]