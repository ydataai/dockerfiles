from __future__ import print_function
import copy
import sys
import logging
import os

import pandas as pd
from collections import Counter
from scipy import stats
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.manifold import TSNE
from sklearn.metrics import f1_score, mean_absolute_error
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.linear_model import Lasso, Ridge, ElasticNet, LogisticRegression

from ._visual_metrics import numerical_encoding, correlation_plot, continuous_density
from ._distance import *

class Evaluator:

    def __init__(self, real: pd.DataFrame, synthetic: pd.DataFrame, cat_cols: list, ordinal_cols=[], verbose=False,
                 n_samples=None):
        '''

        Parameters
        ----------
        real: a pandas dataframe with a sample from the real dataset
        synthetic: a pandas dataframe with a sample from a generated synthetic data
        cat_cols: The columns that are to be considered as categorical from the given datasets
        ordinal_cols: The columns that are to be considered as ordinal from the provided datasets
        verbose: Print or not more detail with the output
        n_samples: Number of samples to be considered under the evaluation tests
        '''
        try:
            assert Counter(real.columns) == Counter(synthetic.columns)
        except AssertionError as e:
            logging.error(
                'The real and synthetic datasets do not match. Real columns: {}   Synthetic columns: {}'.format(
                    real.columns, synthetic.columns))
            sys.exit()
        try:
            assert cat_cols is not None and isinstance(cat_cols, list)
        except AssertionError as e:
            logging.error('Categorical columns must be provided as a list.')
            sys.exit()

        self.cat_cols = cat_cols
        self.ordinal_cols = ordinal_cols
        self.verbose = verbose
        self.n_samples = n_samples

        self.continuous_col = set(list(real.columns)) - (set(cat_cols + ordinal_cols))
        self.num_cols = len(real.columns)
        self.real = real.sample(n_samples)
        self.synthetic = synthetic.sample(n_samples)

    def check_for_dups(self, return_val: bool):
        '''
        Parameters
        ----------
        return_val: Select to return a Dataframe containing the duplicates it True or just the lenght of the duplicates (False)

        Returns The len of the found duplicates or a dataframe containing the duplicates
        -------
        '''
        real_dups = self.real[self.real.duplicated(keep=False)]
        synthetic_dups = self.synthetic[self.synthetic.duplicated(keep=False)]

        if return_val:
            return real_dups, synthetic_dups
        else:
            return len(real_dups), len(synthetic_dups)

    def check_realSyn_dups(self, return_val: bool):
        '''
        Parameters
        ----------
        return_val: Select to return a Dataframe containing the duplicates it True or just the lenght of the duplicates (False)

        Returns The len of the found duplicates or a dataframe containing the duplicates
        -------
        '''
        df = pd.merge(self.real, self.synthetic, indicator=True)
        duplicates = df[df._merge == 'both']

        if return_val:
            return duplicates
        else:
            return len(duplicates)

    def results_visualization(self):
        self.plot_mean_std()
        self.plot_cumsums()
        self.plot_distributions()
        self.plot_correlation_differences()

    def plot_mean_std(self, ax=None):
        '''
        Parameters
        ----------
        ax: Axis to plot the graphic on. If none, a new figure will be created

        Returns a Plot from the data
        -------
        '''
        if ax is None:
            plt.title('Absolute of Mean and Standard deviation of the numeric columns', fontsize=15)
            fig, ax = plt.subplots(1, 1, figsize=(10, 5))

        real = self.real[self.continuous_col]
        synthetic = self.synthetic[self.continuous_col]

        # calc means
        real_mean = np.log(np.add(abs(real.mean()).values, 1e-5))
        synthetic_mean = np.log(np.add(abs(synthetic.mean()).values, 1e-5))

        min_mean = min(real_mean) - 1
        max_mean = max(real_mean) + 1

        line = np.arange(min_mean, max_mean)
        palette = sns.color_palette("mako_r", 6)
        sns.lineplot(x=line, y=line, ax=ax, color='red')
        sns.scatterplot(x=real_mean,
                        y=synthetic_mean, ax=ax, cmap=sns.diverging_palette(275, 240, as_cmap=True))

        ax.lines[0].set_linestyle("--")
        # ax.set_title('Real and synthetic means relation')
        ax.set_xlabel('Real data', fontsize=6, fontweight='bold')
        ax.set_ylabel('Synthetic data', fontsize=6, fontweight='bold')
        ax.tick_params(direction='out', length=6, width=2, labelsize=6)

    def plot_cumsums(self, num_cols):
        num_charts = self.num_cols
        num_rows = max(1, num_charts // num_cols)
        num_rows = num_rows + 1 if num_charts % num_cols != 0 else num_rows

        max_len = 0
        if not self.real.select_dtypes(include=['object']).empty:
            lengths = []
            for d in self.real.select_dtypes(include=['object']):
                lengths.append(max([len(x.strip()) for x in self.real[d].unique().tolist()]))
            max_len = max(lengths)

        row_height = 5 + (max_len // 30)

        fig, ax = plt.subplots(num_rows, num_cols, figsize=(26, row_height * num_rows))
        fig.suptitle('Cumulative sums per feature', fontsize=15)
        axes = ax.flatten()

        for i, col in enumerate(self.real.columns):
            r_col = self.real[col]
            s_col = self.synthetic[col]
            continuous_density(r_col, s_col, ax=axes[i])

        plt.tight_layout(rect=[0, 0.02, 1, 0.98])
        plt.savefig(os.environ['GRAPHS_PATH']+'/cumsum.png')
        plt.close()
        plt.show()

    def plot_distributions(self, num_cols=3):
        num_charts = self.num_cols
        num_rows = max(1, num_charts // num_cols)
        num_rows = num_rows + 1 if num_charts % num_cols != 0 else num_rows

        max_len = 0
        if not self.real.select_dtypes(include=['object']).empty:
            lengths = []
            for d in self.real.select_dtypes(include=['object']):
                lengths.append(max([len(x.strip()) for x in self.real[d].unique().tolist()]))
            max_len = max(lengths)

        row_height = 6 + (max_len // 30)
        fig, ax = plt.subplots(num_rows, num_cols, figsize=(16, row_height * num_rows))
        fig.suptitle('Distribution per feature', fontsize=16)
        axes = ax.flatten()

        for i, col in enumerate(self.real.columns):
            if col not in self.cat_cols + self.ordinal_cols:
                sns.distplot(self.real[col], ax=axes[i], label='Real', color='darkblue', kde_kws={'bw':0.1})
                sns.distplot(self.synthetic[col], ax=axes[i], label='Synthetic', color='orchid', kde_kws={'bw':0.1})
                axes[i].legend()
            else:
                real = self.real.copy()
                synth = self.synthetic.copy()
                real['type'] = 'Real'
                synth['type'] = 'Synthetic'
                concat = pd.concat([real, synth])
                palette = sns.color_palette('coolwarm')

                x, y, hue = col, "proportion", "type"
                ax = (concat[x].groupby(concat[hue])
                      .value_counts(normalize=True)
                      .rename(y)
                      .reset_index()
                      .pipe((sns.barplot, "data"), x=x, y=y, hue=hue, ax=axes[i], saturation=0.8, palette=palette))

                plt.tight_layout(rect=[0, 0.02, 1, 0.98])
        plt.savefig(os.path.join(os.environ['GRAPHS_PATH']+'/distributions.png'))
        plt.close()

    def plot_correlation_differences(self):
        r_corr, s_corr, diff = correlation_plot(self.real, self.synthetic, cont_cols=self.continuous_col)
        return r_corr, s_corr, diff 
    #Change this function to not plot both synth and real in the same figure.
    #Or think about it at least
    def plot_dimensions(self, model='pca'):
        '''
        Parameters
        ----------
        model: Model can either be 'pca' or 'tsne'. The standard choice is PCA.
        Returns a plot of the dimensions resulting from either PCA or TSNE
        -------
        '''
        try:
            assert model in ['pca', 'tsne']
        except:
            logging.error('The chosen model parameter value must be either "pca" or "tsne".')
            return

        real, _ = numerical_encoding(self.real, self.cat_cols, self.ordinal_cols)
        synth, _ = numerical_encoding(self.synthetic, self.cat_cols, self.ordinal_cols)
        
        for model in ['tsne', 'pca']:
            if real is not None and synth is not None:
                if model == 'pca':
                    pca_r = PCA(n_components=2)
                    pca_s = PCA(n_components=2)
    
                    real_t = pca_r.fit_transform(real)
                    synth_t = pca_s.fit_transform(synth)
                else:
                    tsne_r = TSNE(n_components=2)
                    tsne_s = TSNE(n_components=2)
    
                    real_t = tsne_r.fit_transform(real)
                    synth_t = tsne_s.fit_transform(synth)
    
                # Create a pandas dataframe
                real_t = pd.DataFrame(real_t, columns=['Dim_1', 'Dim_2'])
                synth_t = pd.DataFrame(synth_t, columns=['Dim_1', 'Dim_2'])
                real_t['data'] = 'real'
                synth_t['data'] = 'synth'
                dims = pd.concat([real_t, synth_t])
    
                # fig, ax = plt.subplots(1,1, figsize=(12,6))
                palette = sns.color_palette("coolwarm", n_colors=2)
                fig = sns.scatterplot(x='Dim_1', y='Dim_2', 
                                      hue='data',
                                      palette=palette,
                                      data=dims, sizes=(20, 20),
                                      alpha=0.15,
                                      legend=False)
                sns.despine()
                fig.set(xlabel='Dimension 1', ylabel='Dimension 2')
                plt.title("Dimensions reduction with {}".format(model.upper()), fontsize=15)
                plt.savefig(os.environ['GRAPHS_PATH']+f'/{model}.png')
                plt.close()

    def statistical_eval(self):
        '''
        Returns Correlation coefficient of the relation of the basics stats between the real and the synthetic dataset
        -------
        '''
        total_metrics = pd.DataFrame()
        for name in ['real', 'synthetic']:
            ds = getattr(self, name)
            metrics = {}
            num_ds = ds[self.continuous_col]

            for idx, value in num_ds.mean().items():
                metrics['mean_{}'.format(idx)] = value

            for idx, value in num_ds.median().items():
                metrics['median_{}'.format(idx)] = value

            for idx, value in num_ds.std().items():
                metrics['std_{}'.format(idx)] = value

            for idx, value in num_ds.var().items():
                metrics['var_{}'.format(idx)] = value

            total_metrics[name] = metrics.values()

        total_metrics.index = metrics.keys()
        self.statistical_results = total_metrics

        corr, p = stats.spearmanr(total_metrics['real'], total_metrics['synthetic'])
        return corr

    def fit_estimators(self):
        for i, estimator in enumerate(self.r_estimators):
            estimator.fit(self.real_x_train, self.real_y_train)

        for i, estimator in enumerate(self.s_estimators):
            estimator.fit(self.synth_x_train, self.synth_y_train)

    def _instatiate_estimators(self, target_type):
        if target_type == 'regr':
            self.estimators = [
                RandomForestRegressor(n_estimators=20, max_depth=5, random_state=42),
                Lasso(random_state=42),
                Ridge(alpha=1.0, random_state=42),
                ElasticNet(random_state=42)
            ]
        else:
            self.estimators = [
                LogisticRegression(multi_class='auto', solver='lbfgs', max_iter=500, random_state=42),
                RandomForestClassifier(n_estimators=10, random_state=42),
                DecisionTreeClassifier(random_state=42),
            ]

    def _score_estimators(self):
        if self.target_type == 'class':
            score_r2r = [f1_score(self.real_y_test, clf.predict(self.real_x_test), average='micro') for clf in
                         self.r_estimators]
            score_s2s = [f1_score(self.synth_y_test, clf.predict(self.synth_x_test), average='micro') for clf in
                         self.s_estimators]

            score_r2s = [f1_score(self.synth_y_test, clf.predict(self.synth_x_test), average='micro') for clf in
                         self.r_estimators]
            score_f2r = [f1_score(self.real_y_test, clf.predict(self.real_x_test), average='micro') for clf in
                         self.r_estimators]

            index = [f'real_data_{classifier}' for classifier in self.estimators_names] + \
                    [f'synth_data_{classifier}' for classifier in self.estimators_names]
        else:
            score_r2r = [mean_absolute_error(self.real_y_test, clf.predict(self.real_x_test)) for clf in
                         self.r_estimators]
            score_s2s = [mean_absolute_error(self.synth_y_test, clf.predict(self.synth_x_test)) for clf in
                         self.s_estimators]

            score_r2s = [mean_absolute_error(self.synth_y_test, clf.predict(self.synth_x_test)) for clf in
                         self.r_estimators]
            score_f2r = [mean_absolute_error(self.real_y_test, clf.predict(self.real_x_test)) for clf in
                         self.r_estimators]
            index = [f'real_data_{classifier}' for classifier in self.estimators_names] + \
                    [f'synth_data_{classifier}' for classifier in self.estimators_names]

        self.estimators_scores = pd.DataFrame({'real': score_r2r + score_r2s, 'synthetic': score_f2r + score_s2s},
                                              index=index)

        # Calculate the mean of the results?
        if self.target_type == 'class':
            mean = mean_absolute_error(self.estimators_scores['real'], self.estimators_scores['synthetic'])
            return 1 - mean
        else:
            corr, p = stats.spearmanr(self.estimators_scores['real'], self.estimators_scores['synthetic'])
            return corr

    def estimator_eval(self, target_col: str, target_type: str = 'class'):
        def order_cols(df):
            cols = sorted(df.columns.tolist())
            return df[cols]

        try:
            assert target_type in ['class', 'regr']
        except AssertionError as e:
            logging.error('Target type must be either classification (class) or a regression (regr).')

        self.target_col = target_col
        self.target_type = target_type
        cat_cols = self.cat_cols.copy()
        if target_type == 'class':
            cat_cols.remove(target_col)

        real_x, _ = numerical_encoding(self.real.drop([target_col], axis=1), cat_cols=cat_cols)
        synth_x, _ = numerical_encoding(self.synthetic.drop([target_col], axis=1), cat_cols=cat_cols)

        real_x = order_cols(real_x)
        synth_x = order_cols(synth_x)

        if self.target_type == 'class':
            real_y, uniques = pd.factorize(self.real[self.target_col])
            mapping = {key: value for value, key in enumerate(uniques)}
            synth_y = [mapping.get(key) for key in self.synthetic[target_col].tolist()]
        else:
            real_y = self.real[self.target_col]
            synth_y = self.synthetic[self.target_col]

        # Prepare train and test datasets
        self.real_x_train, self.real_x_test, self.real_y_train, self.real_y_test = train_test_split(real_x, real_y,
                                                                                                    test_size=0.25)
        self.synth_x_train, self.synth_x_test, self.synth_y_train, self.synth_y_test = train_test_split(synth_x,
                                                                                                        synth_y,
                                                                                                        test_size=0.25)
        
        self._instatiate_estimators(target_type)
        self.r_estimators = copy.deepcopy(self.estimators)
        self.s_estimators = copy.deepcopy(self.estimators)

        self.estimators_names = [type(clf).__name__ for clf in self.estimators]

        for estimator in self.estimators:
            assert hasattr(estimator, 'fit')
            assert hasattr(estimator, 'score')

        self.fit_estimators()
        similarity = self._score_estimators()

        return similarity

    def calc_distance_metrics(self, real_data, synth_data):
        #MMD
        #Hellinger distance
        #KL Divergence
        #Mudar isto agora e adicionar aos critérios de similaridade :) 
        def mmd(real_data, synth_data):
            return

        def helinger(real_data, synth_data):
            return

        def kl_divergence(real_data, synth_data):
            return


        return 

    def evaluate(self, target_col: str, target_type: str = 'class', n_samples_distance=None):
        self.g_cols = 3

        #calculating the duplicates
        num_duplicates = self.check_realSyn_dups(True)
        print(num_duplicates)

        # generating the plots
        self.plot_cumsums(num_cols=3)
        self.plot_correlation_differences()
        self.plot_distributions(num_cols=3)
        self.plot_dimensions()

        # Regression and Classification evaluation
        similarity = self.estimator_eval(target_col=target_col)
        estimatores_scores = self.estimators_scores

        print(similarity)
        print(estimatores_scores)

        # Print both the datasets into the pdf
        r_preview = self.real.reset_index(drop=True).head(10)
        s_preview = self.synthetic.reset_index(drop=True).head(10)

        kwargs = {"real_dataset": r_preview,
                  "synth_dataset": s_preview,
                  "similarity": similarity,
                  "estimate_scores": estimatores_scores,
                  "num_duplicates": num_duplicates}

        return similarity, estimatores_scores
