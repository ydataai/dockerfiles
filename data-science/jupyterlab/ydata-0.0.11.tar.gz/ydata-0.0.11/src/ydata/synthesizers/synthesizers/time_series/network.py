from __future__ import absolute_import, division, print_function, unicode_literals

from tensorflow.keras.models import load_model
from tensorflow.keras.layers import InputLayer

class Network(object):
    def __init__(self, name):
        self.name = name
        self.model = None

    @property
    def layers(self):
        # Historically, `sequential.layers` only returns layers that were added
        # via `add`, and omits the auto-generated `InputLayer`
        # that comes at the bottom of the stack.
        if self._layers and isinstance(self._layers[0], InputLayer):
            return self._layers[1:]
        return self._layers

    def build_model(self, training=True):
        return NotImplementedError

    def save(self, model, path):
        model.save(path)

    def load(self, path):
        model = load_model(path)
        return model