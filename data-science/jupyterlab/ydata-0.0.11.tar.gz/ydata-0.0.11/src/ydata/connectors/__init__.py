"""
The :mod:`ydata.connectors` module that gathers the data connectors that will be made available at YData's platform
"""
from ydata.connectors.storages.aws_s3_connector import S3Connector
from ydata.connectors.storages.gcs_connector import GCSConnector

__all__ = [
    "S3Connector",
    "GCSConnector"
]
