from __future__ import absolute_import, division, print_function

import os

from rhea import RheaError
from rhea import parser as rhea_parser

import uuid
from datetime import datetime

from botocore.exceptions import ClientError
import pyarrow.parquet as pq
import random
import modin.pandas as pd

from ydata.connectors.storages import _S3_STORAGE, _MAX_SAMPLE
from ydata.connectors.storages import _CSV, _PARQUET, _EXCEL, _FILE_TYPES
from ydata.connectors.clients import aws_client
from ydata.connectors.exceptions import DataConnectorsException, NoDataAvailable
from ydata.connectors.logger import logger
from ydata.connectors.storages.base_connector import BaseConnector

from ydata.connectors.utils import (
    get_files_in_current_directory
)

class S3Connector(BaseConnector):
    """
    S3 store service using Modian
    """
    STORAGE_TYPE = _S3_STORAGE
    ENCRYPTION = "AES256"

    def __init__(self, access_key_id, secret_access_key, aws_ssl=True,
                 session_token = None, aws_region=None, ds=None ,**kwargs):
        BaseConnector.__init__(self)
        self._filesystem = None
        self._resource = None
        self._client = None

        if ds is None:
            self._encoding = kwargs.get('encoding', 'utf-8')
            self._endpoint_url = (kwargs.get('endpoint_url') or
                                  kwargs.get('aws_endpoint_url') or
                                  kwargs.get('AWS_ENDPOINT_URL'))

            self._aws_access_key_id = access_key_id
            self._aws_secret_access_key = secret_access_key
            self._aws_session_token = session_token
            self._region_name = aws_region
            self._aws_use_ssl = aws_ssl

            # Not mandatory anymore for that reason will be kept as a kwarg
            self._aws_verify_ssl = kwargs.get('verify_ssl',
                                              kwargs.get('aws_verify_ssl',
                                              kwargs.get('AWS_VERIFY_SSL', None)))

            self.credentials = {
                'aws_access_key_id': self._aws_access_key_id,
                'aws_secret_access_key': self._aws_secret_access_key,
                'aws_session_token': self._aws_session_token,
                'aws_verify_ssl': self._aws_verify_ssl,
                'aws_use_ssl': self._aws_use_ssl,
                'endpoint_url': self._endpoint_url,
                'region': self._region_name
            }
        else:
            self.credentials = ds.credentials

        self._filesystem = self.filesystem

    @property
    def client(self):
        if self._client is None:
            self.set_client(self.credentials)
        return self._client

    def set_client(self,
                   credentials):
        """
        Sets a new s3 boto3 client.
        Args:
            endpoint_url: `str`. The complete URL to use for the constructed client.
            aws_access_key_id: `str`. The access key to use when creating the client.
            aws_secret_access_key: `str`. The secret key to use when creating the client.
            aws_session_token: `str`. The session token to use when creating the client.
            region_name: `str`. The name of the region associated with the client.
                A client is associated with a single region.
        Returns:
            Service client instance
        """
        self._client = aws_client.get_aws_client(
            's3',
            endpoint_url=credentials['endpoint_url'],
            aws_access_key_id=credentials['aws_access_key_id'],
            aws_secret_access_key=credentials['aws_secret_access_key'],
            aws_session_token=credentials['aws_session_token'],
            region_name=credentials['region'],
            aws_use_ssl=credentials['aws_use_ssl'],
            aws_verify_ssl=credentials['aws_verify_ssl'])

    def set_env_vars(self):
        if self.credentials['endpoint_url']:
            os.environ['AWS_ENDPOINT_URL'] = self.credentials['endpoint_url']
        if self.credentials['aws_access_key_id']:
            os.environ['AWS_ACCESS_KEY_ID'] = self.credentials['aws_access_key_id']
        if self.credentials['aws_secret_access_key']:
            os.environ['AWS_SECRET_ACCESS_KEY'] = self.credentials['aws_secret_access_key']
        if self.credentials['aws_session_token']:
            os.environ['AWS_SECURITY_TOKEN'] = self.credentials['aws_session_token']
        if self.credentials['region']:
            os.environ['AWS_REGION'] = self.credentials['region']
        if self.credentials['aws_use_ssl'] is not None:
            os.environ['AWS_USE_SSL'] = str(self.credentials['aws_use_ssl'])
        if self.credentials['aws_verify_ssl'] is not None:
            os.environ['AWS_VERIFY_SSL'] = self.credentials['aws_verify_ssl']

    def set_filesystem(self,
                       credentials):
        """
        Sets a new s3fs S3FileSystem client
        Args:
            credentials that include the following properties
            endpoint_url: `str`. The complete URL to use for the constructed client.
            aws_access_key_id: `str`. The access key to use when creating the client.
            aws_secret_access_key: `str`. The secret key to use when creating the client.
            aws_session_token: `str`. The session token to use when creating the client.
            region_name: `str`. The name of the region associated with the client.
                A client is associated with a single region.
        Returns:
            Service client instance
        """
        self._filesystem = aws_client.get_aws_filesystem(
            credentials)
        
    @property
    def resource(self):
        if self._resource is None:
            kwargs = self.credentials
            self.set_resource(**kwargs)
        return self._resource

    def set_resource(self,
                     **kwargs):
        """
        Sets a new s3 boto3 resource.
        Args:
            endpoint_url: `str`. The complete URL to use for the constructed client.
            aws_access_key_id: `str`. The access key to use when creating the client.
            aws_secret_access_key: `str`. The secret key to use when creating the client.
            aws_session_token: `str`. The session token to use when creating the client.
            region_name: `str`. The name of the region associated with the client.
                A client is associated with a single region.
        Returns:
             Service resource instance
        """
        self._resource = aws_client.get_aws_resource(
            's3',
            endpoint_url=kwargs.get('endpoint_url'),
            aws_access_key_id=kwargs.get('aws_access_key_id'),
            aws_secret_access_key=kwargs.get('aws_secret_access_key'),
            aws_session_token=kwargs.get('aws_session_token'),
            region_name=kwargs.get('region')
        ) 

    @property
    def filesystem(self):
        #define the aws client using the giving credentials and s3fs
        self.set_filesystem(self.credentials)
        return self._filesystem

    @staticmethod
    def parse_s3_url(s3_url):
        """
        Parses and validates an S3 url.
        Returns:
             tuple(bucket_name, key).
        """
        try:
            spec = rhea_parser.parse_s3_path(s3_url)
            return spec.bucket, spec.key
        except RheaError as e:
            raise DataConnectorsException(e)

    @staticmethod
    def check_prefix_format(prefix, delimiter):
        if not delimiter or not prefix:
            return prefix
        return prefix + delimiter if prefix[-1] != delimiter else prefix

    def check_bucket(self, bucket_name):
        """
        Checks if a buckete exists.
        Args:
            bucket_name: `str`. Name of the bucket
        """
        try:
            self.client.head_bucket(Bucket=bucket_name)
            return True
        except ClientError as e:
            logger.info(e.response["Error"]["Message"])
            return False

    def get_bucket(self, bucket_name):
        """
        Gets a bucket by name.
        Args:
            bucket_name: `str`. Name of the bucket
        """
        return self.resource.Bucket(bucket_name)

    def get_key(self, key, bucket_name=None):
        """
        Returns a boto3.s3.Object
        Args:
            key: `str`. the path to the key.
            bucket_name: `str`. the name of the bucket.
        """
        if not bucket_name:
            (bucket_name, key) = self.parse_s3_url(key)

        try:
            obj = self.resource.Object(bucket_name, key)
            obj.load()
            return obj
        except Exception as e:
            raise DataConnectorsException(e)

    def read_key(self, key, bucket_name=None):
        """
        Reads a key from S3
        Args:
            key: `str`. S3 key that will point to the file.
            bucket_name: `str`. Name of the bucket in which the file is stored.
        """
    
        obj = self.get_key(key, bucket_name)
        return obj.get()['Body'].read().decode('utf-8')

    def ls(self, path):
        (bucket_name, key) = self.parse_s3_url(path)
        results = self.list(bucket_name=bucket_name, prefix=key)
        return {'files': results['keys'], 'dirs': results['prefixes']}

    def list(self,
             bucket_name,
             prefix='',
             delimiter='/',
             page_size=None,
             max_items=None,
             keys=True,
             prefixes=True):
        """
        Lists prefixes and contents in a bucket under prefix.
        Args:
            bucket_name: `str`. the name of the bucket
            prefix: `str`. a key prefix
            delimiter: `str`. the delimiter marks key hierarchy.
            page_size: `str`. pagination size
            max_items: `int`. maximum items to return
            keys: `bool`. if it should include keys
            prefixes: `boll`. if it should include prefixes
        """
        config = {
            'PageSize': page_size,
            'MaxItems': max_items,
        }

        paginator = self.client.get_paginator('list_objects_v2')

        prefix = self.check_prefix_format(prefix=prefix, delimiter=delimiter)
        response = paginator.paginate(Bucket=bucket_name,
                                      Prefix=prefix,
                                      Delimiter=delimiter,
                                      PaginationConfig=config)

        def get_keys(contents):
            list_keys = []
            for cont in contents:
                list_keys.append((cont['Key'][len(prefix):], cont.get('Size')))

            return list_keys

        def get_prefixes(page_prefixes):
            list_prefixes = []
            for pref in page_prefixes:
                list_prefixes.append(pref['Prefix'][len(prefix): -1])
            return list_prefixes

        results = {
            'keys': [],
            'prefixes': []
        }
        for page in response:
            if prefixes:
                results['prefixes'] += get_prefixes(page.get('CommonPrefixes', []))
            if keys:
                results['keys'] += get_keys(page.get('Contents', []))

        return results

    def list_keys(self, bucket_name, prefix='', delimiter='', page_size=None, max_items=None):
        """
        Lists keys in a bucket under prefix and not containing delimiter
        Args:
            bucket_name: `str`. the name of the bucket
            prefix: `str`. a key prefix
            delimiter: `str`. the delimiter marks key hierarchy.
            page_size: `int`. pagination size
            max_items: `int`. maximum items to return
        """
        results = self.list(bucket_name=bucket_name,
                            prefix=prefix,
                            delimiter=delimiter,
                            page_size=page_size,
                            max_items=max_items,
                            keys=True,
                            prefixes=False)
        return results['keys']

    def check_key(self, key, bucket_name=None):
        """
        Checks if a key exists in a bucket
        Args:
            key: `str`. S3 key that will point to the file
            bucket_name: `str`. Name of the bucket in which the file is stored
        """
        if not bucket_name:
            (bucket_name, key) = self.parse_s3_url(key)

        try:
            self.client.head_object(Bucket=bucket_name, Key=key)
            return True
        except ClientError as e:
            logger.info(e.response["Error"]["Message"])
            return False
          
    def _check_path(self, file_type, path):
        assert file_type in _FILE_TYPES, f"Provided file type {file_type} is not supported."

        bucket, filename = self.parse_s3_url(path)
        extension = self.check_file_extension(filename)

        if extension != file_type and extension is not None:
            raise DataConnectorsException(f'File type {file_type} not in {_FILE_TYPES}.')

        if extension is None:
            files = self.ls(path)['files']
            file_paths = [os.path.join(path, file[0]).replace('S3', 's3') for file in files if self.check_file_extension(file[0]) == file_type]
            _, filename = self.parse_s3_url(path)
        else:
            file_paths = [path.replace('S3', 's3')]

        return file_paths, bucket, filename

    def read_sample(self, path=None, file_type=_CSV):
        """
        Args:
            path: 'str'. S3 path for the file/s to be read
            file_type: 'str'. Type of file to be read. Can be a CSV, PARQUET, XLSX or AVRO
        Returns: Modin pandas dataframe with a subset of the data stored in the given S3 path
        """
        file_paths, bucket, filename = self._check_path(file_type=file_type, path=path)
        fs = self._filesystem

        n = sum(1 for line in fs.open(file_paths[0])) - 1
        if n > _MAX_SAMPLE:
            p = _MAX_SAMPLE / n
        else:
            p = 1

        try:
            if file_type == _EXCEL:
                n = sum(1 for line in open(file_paths[0])) - 1
                with fs.open(file_paths[0], 'r') as f:
                    data = pd.read_excel(f, skiprows=lambda i: i>0 and random.random() > p)
            elif file_type == _PARQUET:
                dataset = pq.ParquetDataset(file_paths[0], filesystem=self.filesystem, buffer_size=1000)
                data = pd.DataFrame(dataset.read_pandas().to_pandas())
            else:
                with fs.open(file_paths[0], 'r') as f:
                    data = pd.read_csv(f, skiprows=lambda i: i>0 and random.random() > p)
        except PermissionError:
            raise DataConnectorsException(f'Its not possible to read the provided files from the S3 bucket {bucket}.'
                                          'Please revise your credentials or file path.')

        return data

    def read_file(self, path=None, file_type=_CSV):
        """
        Reads a file from S3.
        Args:
            path: `str`. S3 path for the file/s to be read
        :return Modin pandas object with the data stored in a given S3 file
        """
        fs = self._filesystem
        file_paths,_,_ = self._check_path(file_type=file_type, path=path)

        ls_data = []
        for file in file_paths:
            try:
                if file_type == _EXCEL:
                    with fs.open(file, 'r') as f:
                        ls_data.append(pd.read_excel(f))
                elif file_type == _PARQUET:
                    dataset = pq.ParquetDataset(file, filesystem=self.filesystem)
                    ls_data.append(pd.DataFrame(dataset.read_pandas().to_pandas()))
                else:
                    with fs.open(file, 'r') as f:
                        ls_data.append(pd.read_csv(f))
            except PermissionError:
                raise DataConnectorsException(f'Its not possible to read the provided files from the S3 bucket {bucket}.'
                                              'Please revise your credentials or file path.')
        try:
            dataset = pd.concat(ls_data)
        except:
            raise DataConnectorsException(f'Its not possible to read all files in the given {path}.'
                                          f'Please verify their structure')

        return dataset
      
    def write_to(self, df, path, file_type=_CSV):
        fs = self._filesystem
        try:
            self.parse_s3_url(path)
        except:
            DataConnectorsException('Please provide a valid s3 path.')

        if file_type == _EXCEL:
            with fs.open(path, 'w') as f:
                df.to_excel(f)
        elif file_type == _PARQUET:
            with fs.open(path, 'wb') as f:
                df.to_parquet(f)
        else:
            with fs.open(path, 'w') as f:
                df.to_csv(f)