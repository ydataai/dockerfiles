# ydata
YData propriatery lib with services for data synthesizing and data quality. The lib is composed by the following elements:

 - Connectors: Read data from multiple data sources - file storages, RDBMS, etc.
 - Synthesizers: Regular and time-series data
 - Utils: A series of useful packages for data analysis and report automation.
