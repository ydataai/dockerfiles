from __future__ import absolute_import, division, print_function

import os
from io import BytesIO

from azure.core.exceptions import ResourceNotFoundError, HttpResponseError
import pandas as pd

from ydata.connectors import get_blob_service_connection
from ydata.connectors import DataConnectorsException
from ydata.connectors import _AZURE_STORAGE, _FILE_TYPES, _CSV
from ydata.connectors import BaseConnector


class AzureBlobConnector(BaseConnector):
    """
        Azure Blob storage connector.
    """
    STORE_TYPE = _AZURE_STORAGE

    def __init__(self, ds=None,**kwargs):
        BaseConnector.__init__(self)

        if ds == None:
            self._connection_string = (
                    kwargs.get('connection_string') or kwargs.get('AZURE_CONNECTION_STRING'))
            self.credentials = {
                'connection_string': self._connection_string
            }
            self.set_env_vars()
        else:
            self.credentials = ds.credentials
            self._client = ds.client
            self.set_env_vars()
        #Setting the environment variables for the storage

    @property
    def client(self):
        return self.set_connection(connection_string=self.credentials['connection_string'])

    def set_connection(self, connection_string=None):
        """
        Sets a new Blob service connection.
        Args:
            - connection_string: 'str' If specified shall override all other parameters
        Returns:
            BlockBlobService instance
        """
        return get_blob_service_connection(connection_string=connection_string)

    def set_env_vars(self):
        if self._connection_string:
            os.environ['AZURE_CONNECTION_STRING'] = self.credentials['connection_string']

    def get_storage_account_information(self):
        account_info = self.client.get_account_information()
        return account_info

    def list_containers(self, startswith=None, include_metadata=False):
        """
        Returns the list of the existing containers for a given account.
        Args:
            startswith: 'str'. Beginning of the container name that we are looking for
            include_metadata: 'bool'. True or False depending on wanting or not metadata to be retrieved.
        Returns: A list containing the existing containers metadata.
        Returns: A list containing the existing containers metadata.
        """
        all_containers = []
        try:
            if startswith is None:
                for container in self.client.list_containers(include_metadata=include_metadata):
                    all_containers.append(container)
            else:
                for container in self.client.list_containers(name_starts_with='sampl', include_metadata=include_metadata):
                    all_containers.append(container)
        except:
            DataConnectorsException('Error while trying to list the available containers. Please verify Blob credentials.')
        return all_containers

    def list_blobs(self, container_name):
        """
        Gets the list of existing blobs in a container. 
        Args:
            container_name: 'str'. Name of the container
        Returns: 'list'. A list with all existing blobs
        """
        all_blobs = []
        container_client = self.client.get_container_client(container=container_name)
        try:
            for blob in container_client.list_blobs():
                all_blobs.append(blob)
        except ResourceNotFoundError:
            raise DataConnectorsException("Container not found.")
        return all_blobs

    def read_file(self, container_name, filename, file_type=_CSV):
        """
        Method to read file(s) stored in an Azure Blob.
        Args:
            container_name: Name of the container wher the file is stored
            blob_name: Name of the file to be read. If provided will read only one file
            file_type: Type of the file(s) to be read

        Returns: pd.Dataframe. A dataframe containing the stored data
        """
        blob_client = self.client.get_blob_client(container=container_name, blob=filename)
        try:
            blob_stream = blob_client.download_blob()
            with BytesIO() as input_blob:
                blob_client.download_blob().download_to_stream(input_blob)
                input_blob.seek(0)

                if file_type == _CSV:
                    df = pd.read_csv(input_blob)
        except ResourceNotFoundError:
            raise DataConnectorsException("No blob found.")
        return df

    def write_to(self, df, container_name, filename, file_type=_CSV):
        """
        Args:
            df: 'pd.Dataframe'. Dataframe to be written as a blob in Azure Blob Storage.
            container_name: 'str'. Name of the container. If doesn't exist, it's created.
            filename: 'str'. Name of the blob to be written in Azure Blob storage.
            file_type: 'str. File extension
        """
        assert file_type in _FILE_TYPES, f"Provided file type is not valid. Please provide one of the following {_FILE_TYPES}"
        assert filename.split('.')[1] == file_type, "File extension should match provided file type."

        #check whether the container is already created
        try:
            container_client = self.client.get_container_client(container=container_name)
            container_client.create_container()
        except:
            pass

        blob_client = self.client.get_blob_client(container=container_name, blob=filename)

        try:
            output = df.to_csv(index=False, encoding="utf-8")
            blob_client.upload_blob(output, blob_type="BlockBlob")
        except HttpResponseError:
            raise DataConnectorsException('It was not possible to write the data in the given path.')
