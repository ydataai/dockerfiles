"""
The :mod:`ydata.synthesizers.regular` module that gathers the different algorithms for regular data synthetization
"""
from ._model import RegularSynthesizer

__all__ = [
           'RegularSynthesizer'
           ]