"""
Missing values inputation for time-series and regular tabular data. 
"""
import modin.pandas as pd

def missingval(df: pd.DataFrame):
    """
    Parameters
    ----------
    df Dataframe with the dataset to be inputed with the missing values
    Returns A Dataframe with the missing information inputed
    -------
    """
    return